@echo off
title AntiScam Music Server Bot
cd /d "%~dp0"

where py >nul 2>nul
if errorlevel 1 (
  echo Python launcher was not found.
  echo Install Python 3.12 from python.org and check "Add Python to PATH".
  pause
  exit /b 1
)

py -3.12 --version >nul 2>nul
if errorlevel 1 (
  echo Python 3.12 was not found.
  echo Install Python 3.12 and run this file again.
  pause
  exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
  echo Creating virtual environment...
  py -3.12 -m venv .venv
)

call ".venv\Scripts\activate.bat"
python -m pip install --upgrade pip
pip install -r requirements.txt

if not exist "config.json" (
  copy /Y "config.example.json" "config.json" >nul
  echo.
  echo Created config.json.
  echo Edit config.json and add your Discord bot token and log channel ID.
  pause
  exit /b 0
)

python bot.py
echo.
echo Bot stopped with exit code %errorlevel%.
pause
