
# AntiScam Music Server Bot

A Discord moderation bot for music-production communities that removes common stolen-account scam posts and temporarily quarantines the account that posted them.

## What it catches

- Common **MrBeast giveaway / fake crypto / fake bonus** scam wording
- **"Join/check the link in my bio"** scam lures
- Common **NSFW solicitation/spam text**
- Suspicious links and admin-configured blocked domains
- Text inside Discord embeds
- Known recurring scam screenshots using **perceptual image fingerprints**
- Optional extra scrutiny for newly-created Discord accounts

When a high-confidence match is found, the bot can delete the message, timeout the sender, log the incident to a private moderator channel, and store it in SQLite.

The default is a **temporary timeout instead of an automatic permanent ban**, because legitimate members can have their Discord accounts compromised.

## Image / NSFW note

A text-rule bot cannot reliably identify every arbitrary explicit image. This build is intended to be used together with Discord's native Safety/explicit-media protections. It also lets you fingerprint recurring scam screenshots with `!antiscam_hash`, so reposted/recompressed copies can be caught automatically.

## Setup

1. Install **Python 3.12**.
2. Create a Discord application/bot in the Discord Developer Portal.
3. Enable **Message Content Intent** and **Server Members Intent**.
4. Invite the bot with:
   - View Channels
   - Send Messages
   - Read Message History
   - Manage Messages
   - Moderate Members
   - Embed Links
5. Put the bot's role **above normal member roles**.
6. Copy `config.example.json` to `config.json`.
7. Put your bot token and log-channel ID in `config.json`.
8. Run `start.bat`.

## Commands

- `!antiscam_status`
- `!antiscam_hash` — attach a known scam screenshot, or reply to one
- `!antiscam_unhash <hash>`
- `!antiscam_incidents`
- `!antiscam_help`

## Timeout

In `config.json`, `1440` minutes = 24 hours:

```json
"timeout_minutes": 1440
```

## Blocked domains

Add known scam domains:

```json
"blocked_domains": [
  "example-scam-domain.com"
]
```

## Phrase tuning

Edit `mrbeast_phrases`, `bio_scam_phrases`, and `nsfw_text_phrases` in `config.json`, then restart.
