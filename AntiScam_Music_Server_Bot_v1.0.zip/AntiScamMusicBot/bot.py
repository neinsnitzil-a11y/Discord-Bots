
import io
import json
import logging
import re
import sqlite3
from datetime import timedelta
from pathlib import Path
from urllib.parse import urlparse

import discord
from discord.ext import commands
from PIL import Image
import imagehash

BASE_DIR = Path(__file__).resolve().parent
CONFIG_PATH = BASE_DIR / "config.json"
DB_PATH = BASE_DIR / "antiscam.db"

DEFAULT_CONFIG = {
    "token": "",
    "command_prefix": "!",
    "log_channel_id": 0,
    "moderator_role_ids": [],
    "timeout_minutes": 1440,
    "delete_suspicious_messages": True,
    "block_new_accounts_days": 0,
    "safe_domains": [
        "discord.com", "discord.gg", "youtube.com", "youtu.be",
        "soundcloud.com", "spotify.com", "open.spotify.com",
        "bandcamp.com", "github.com"
    ],
    "blocked_domains": [],
    "mrbeast_phrases": [
        "mrbeast giveaway", "mr beast giveaway", "mrbeast crypto",
        "mr beast crypto", "claim your prize", "you won $",
        "you have won $", "free $5000", "free $10000",
        "limited giveaway", "withdrawal success",
        "activate code for bonus", "promo code", "stake promo", "stake bonus"
    ],
    "bio_scam_phrases": [
        "link in my bio", "join the link in my bio", "check link in bio",
        "check my bio", "18+ in bio", "nsfw in bio", "nudes in bio",
        "onlyfans in bio", "free nudes", "dm me for nudes",
        "add my snap", "telegram in bio"
    ],
    "nsfw_text_phrases": [
        "free nudes", "send nudes", "nude pack", "leaks in bio",
        "18+ content", "nsfw content", "onlyfans leak", "sex tape"
    ],
    "suspicious_tlds": [".zip", ".mov", ".click", ".top", ".xyz", ".work", ".cam"],
    "known_bad_image_hashes": [],
    "image_hash_distance": 6
}

URL_RE = re.compile(r'https?://[^\s<>()]+', re.I)
MONEY_RE = re.compile(r'\$\s?(?:[1-9]\d{2,}|[1-9]\d?(?:,\d{3})+)', re.I)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s"
)
log = logging.getLogger("antiscam")

def load_config():
    if not CONFIG_PATH.exists():
        CONFIG_PATH.write_text(json.dumps(DEFAULT_CONFIG, indent=2), encoding="utf-8")
        raise SystemExit("Created config.json. Put your bot token/settings in it, then restart.")
    data = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    return DEFAULT_CONFIG | data

config = load_config()

intents = discord.Intents.default()
intents.message_content = True
intents.members = True

bot = commands.Bot(
    command_prefix=config["command_prefix"],
    intents=intents,
    help_command=None
)

def init_db():
    con = sqlite3.connect(DB_PATH)
    con.execute("""
        CREATE TABLE IF NOT EXISTS incidents(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            guild_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            channel_id INTEGER NOT NULL,
            message_id INTEGER NOT NULL,
            reason TEXT NOT NULL,
            content TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    con.commit()
    con.close()

init_db()

def norm(s: str) -> str:
    return re.sub(r'\s+', ' ', (s or "").lower()).strip()

def hostname(url: str) -> str:
    try:
        h = (urlparse(url).hostname or "").lower()
        return h[4:] if h.startswith("www.") else h
    except Exception:
        return ""

def domain_allowed(host: str) -> bool:
    for d in config["safe_domains"]:
        d = d.lower().strip()
        if host == d or host.endswith("." + d):
            return True
    return False

def domain_blocked(host: str) -> bool:
    for d in config["blocked_domains"]:
        d = d.lower().strip()
        if host == d or host.endswith("." + d):
            return True
    return False

def is_mod(member: discord.Member) -> bool:
    if member.guild_permissions.administrator or member.guild_permissions.manage_messages:
        return True
    allowed = set(int(x) for x in config.get("moderator_role_ids", []))
    return any(role.id in allowed for role in member.roles)

def score_text(content: str):
    text = norm(content)
    reasons = []
    score = 0

    for p in config["mrbeast_phrases"]:
        if p.lower() in text:
            score += 5
            reasons.append(f"MrBeast/giveaway phrase: {p}")

    for p in config["bio_scam_phrases"]:
        if p.lower() in text:
            score += 5
            reasons.append(f"bio scam phrase: {p}")

    for p in config["nsfw_text_phrases"]:
        if p.lower() in text:
            score += 4
            reasons.append(f"NSFW solicitation phrase: {p}")

    urls = URL_RE.findall(content or "")
    if urls:
        for u in urls:
            host = hostname(u)
            if domain_blocked(host):
                score += 6
                reasons.append(f"blocked domain: {host}")
            elif host and not domain_allowed(host):
                score += 1
                reasons.append(f"unrecognized external domain: {host}")

            low = u.lower()
            if any(tld in low for tld in config["suspicious_tlds"]):
                score += 2
                reasons.append("suspicious link/TLD")

    if MONEY_RE.search(text) and any(k in text for k in ("giveaway", "won", "bonus", "claim", "withdraw")):
        score += 4
        reasons.append("large-money giveaway language")

    if ("mrbeast" in text or "mr beast" in text) and urls:
        score += 4
        reasons.append("MrBeast reference combined with external link")

    if any(k in text for k in ("link in my bio", "check my bio")) and urls:
        score += 3
        reasons.append("bio lure combined with link")

    return score, reasons

async def image_matches_known_bad(attachment: discord.Attachment):
    if not attachment.content_type or not attachment.content_type.startswith("image/"):
        return False, None
    try:
        data = await attachment.read()
        img = Image.open(io.BytesIO(data)).convert("RGB")
        h = imagehash.phash(img)
        threshold = int(config.get("image_hash_distance", 6))
        for stored in config.get("known_bad_image_hashes", []):
            try:
                bad = imagehash.hex_to_hash(stored)
                dist = h - bad
                if dist <= threshold:
                    return True, f"known scam image match (distance={dist})"
            except Exception:
                continue
        return False, str(h)
    except Exception as e:
        log.warning("Image hash failed: %s", e)
        return False, None

async def write_incident(message: discord.Message, reason: str):
    con = sqlite3.connect(DB_PATH)
    con.execute(
        "INSERT INTO incidents(guild_id,user_id,channel_id,message_id,reason,content) VALUES(?,?,?,?,?,?)",
        (
            message.guild.id,
            message.author.id,
            message.channel.id,
            message.id,
            reason,
            (message.content or "")[:3000],
        ),
    )
    con.commit()
    con.close()

async def send_log(message: discord.Message, reason: str, action: str):
    cid = int(config.get("log_channel_id") or 0)
    channel = message.guild.get_channel(cid) if cid else None
    if not channel:
        return
    embed = discord.Embed(
        title="🛡️ Anti-Scam Action",
        description=f"**Action:** {action}\n**Reason:** {reason}",
        timestamp=discord.utils.utcnow(),
    )
    embed.add_field(name="User", value=f"{message.author} (`{message.author.id}`)", inline=False)
    embed.add_field(name="Channel", value=message.channel.mention, inline=True)
    embed.add_field(name="Message ID", value=str(message.id), inline=True)
    if message.content:
        embed.add_field(name="Content", value=message.content[:1000], inline=False)
    await channel.send(embed=embed)

async def punish(message: discord.Message, reason: str):
    action_parts = []
    if config.get("delete_suspicious_messages", True):
        try:
            await message.delete()
            action_parts.append("message deleted")
        except discord.Forbidden:
            action_parts.append("could not delete (missing permission)")
        except discord.NotFound:
            pass

    member = message.author
    minutes = int(config.get("timeout_minutes", 1440))
    if isinstance(member, discord.Member) and not is_mod(member):
        try:
            until = discord.utils.utcnow() + timedelta(minutes=minutes)
            await member.timeout(until, reason=f"Anti-scam: {reason[:350]}")
            action_parts.append(f"timed out {minutes} minutes")
        except discord.Forbidden:
            action_parts.append("could not timeout (role/permission issue)")
        except Exception as e:
            action_parts.append(f"timeout error: {type(e).__name__}")

    await write_incident(message, reason)
    await send_log(message, reason, ", ".join(action_parts) or "logged")

@bot.event
async def on_ready():
    log.info("Logged in as %s (%s)", bot.user, bot.user.id)
    log.info("Watching %s guild(s)", len(bot.guilds))

@bot.event
async def on_message(message: discord.Message):
    if not message.guild or message.author.bot:
        return

    if isinstance(message.author, discord.Member) and is_mod(message.author):
        await bot.process_commands(message)
        return

    score, reasons = score_text(message.content or "")

    for e in message.embeds:
        embed_text = " ".join(
            x for x in [e.title, e.description, getattr(e.author, "name", None)] if x
        )
        s, r = score_text(embed_text)
        score += s
        reasons.extend(r)

    for a in message.attachments:
        match, detail = await image_matches_known_bad(a)
        if match:
            score += 10
            reasons.append(detail)
        s, r = score_text(a.filename)
        score += s
        reasons.extend(r)

    days = int(config.get("block_new_accounts_days", 0))
    if days > 0 and isinstance(message.author, discord.Member):
        age = discord.utils.utcnow() - message.author.created_at
        if age.days < days and score >= 3:
            score += 2
            reasons.append(f"account newer than {days} days")

    if score >= 5:
        unique = list(dict.fromkeys(reasons))
        await punish(message, "; ".join(unique)[:900])
        return

    await bot.process_commands(message)

@bot.command(name="antiscam_status")
@commands.has_permissions(manage_guild=True)
async def antiscam_status(ctx: commands.Context):
    await ctx.reply(
        f"✅ AntiScam is active.\n"
        f"Timeout: **{config['timeout_minutes']} min**\n"
        f"Known bad image hashes: **{len(config.get('known_bad_image_hashes', []))}**"
    )

@bot.command(name="antiscam_hash")
@commands.has_permissions(manage_guild=True)
async def antiscam_hash(ctx: commands.Context):
    target = None
    if ctx.message.attachments:
        target = ctx.message.attachments[0]
    elif ctx.message.reference and ctx.message.reference.resolved:
        ref = ctx.message.reference.resolved
        if isinstance(ref, discord.Message) and ref.attachments:
            target = ref.attachments[0]

    if not target:
        await ctx.reply("Attach an image or reply to a message containing the scam image.")
        return

    if not target.content_type or not target.content_type.startswith("image/"):
        await ctx.reply("That attachment is not an image.")
        return

    try:
        data = await target.read()
        img = Image.open(io.BytesIO(data)).convert("RGB")
        h = str(imagehash.phash(img))
    except Exception:
        await ctx.reply("I could not read that image.")
        return

    raw = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    hashes = raw.setdefault("known_bad_image_hashes", [])
    if h not in hashes:
        hashes.append(h)
        CONFIG_PATH.write_text(json.dumps(raw, indent=2), encoding="utf-8")
        config["known_bad_image_hashes"] = hashes
    await ctx.reply(f"✅ Saved scam-image fingerprint `{h}`.")

@bot.command(name="antiscam_unhash")
@commands.has_permissions(manage_guild=True)
async def antiscam_unhash(ctx: commands.Context, hash_value: str):
    raw = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    hashes = raw.setdefault("known_bad_image_hashes", [])
    if hash_value in hashes:
        hashes.remove(hash_value)
        CONFIG_PATH.write_text(json.dumps(raw, indent=2), encoding="utf-8")
        config["known_bad_image_hashes"] = hashes
        await ctx.reply("✅ Removed that fingerprint.")
    else:
        await ctx.reply("Fingerprint not found.")

@bot.command(name="antiscam_incidents")
@commands.has_permissions(manage_guild=True)
async def antiscam_incidents(ctx: commands.Context):
    con = sqlite3.connect(DB_PATH)
    rows = con.execute(
        "SELECT user_id, reason, created_at FROM incidents WHERE guild_id=? ORDER BY id DESC LIMIT 10",
        (ctx.guild.id,),
    ).fetchall()
    con.close()
    if not rows:
        await ctx.reply("No incidents logged yet.")
        return
    lines = [f"`{ts}` <@{uid}> — {reason[:120]}" for uid, reason, ts in rows]
    await ctx.reply("\n".join(lines)[:1900])

@bot.command(name="antiscam_help")
async def antiscam_help(ctx: commands.Context):
    await ctx.reply(
        "**AntiScam commands**\n"
        "`!antiscam_status` — status\n"
        "`!antiscam_hash` — attach/reply to a known scam image to fingerprint it\n"
        "`!antiscam_unhash <hash>` — remove a fingerprint\n"
        "`!antiscam_incidents` — last 10 incidents\n"
        "Admin/Manage Server permission is required for moderation commands."
    )

if not config.get("token"):
    raise SystemExit("Put your Discord bot token in config.json.")

bot.run(config["token"])
