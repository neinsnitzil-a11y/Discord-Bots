
# AntiScam Music Server Bot v2.1.0

A more advanced anti-scam moderation bot aimed at Discord music-production communities.

## Protection layers

### Scam language engine
Normalizes Unicode, spacing, zero-width characters and common leetspeak before scanning. Detects common:
- MrBeast giveaway/bonus/crypto scams
- "link in my bio" / NSFW lure spam
- fake verification / free Nitro / credential theft lures
- large-money prize language

### URL risk engine
- allow-list and block-list support
- suspicious TLD scoring
- URL-shortener scoring
- punycode/IDN warning
- extra scoring when brand impersonation appears with a link
- per-server allow/block overrides stored in SQLite

### Account-risk signals
New account age and new-server-member age increase the score, but do not punish a user on their own.

### Raid/campaign protection
- per-user rapid-message burst detection
- duplicate-message campaign detection across multiple accounts

### Image fingerprint protection
Staff can teach the bot recurring scam screenshots. It uses perceptual hashes, so resized/recompressed versions can still match.

### Escalating punishment
The score determines the action:
- lower confidence: delete
- medium: short timeout
- higher: long timeout
- extreme: ban

All thresholds are configurable in `config.json`.

### Moderator control center
Run:

`!guard_panel`

You get Discord buttons for:
- status
- allow domain
- block domain
- recent incidents

Incident log messages also have moderator buttons:
- Release Timeout
- Mark False Positive
- Ban Account

### Local audit database
`antiscam.db` stores incident history, per-server domain overrides and image fingerprints.

## Setup

1. Install Python 3.12.
2. Create a Discord bot in the Developer Portal.
3. Enable:
   - Message Content Intent
   - Server Members Intent
4. Invite it with:
   - View Channels
   - Send Messages
   - Read Message History
   - Manage Messages
   - Moderate Members
   - Ban Members
   - Manage Roles (only if using a quarantine role)
   - Embed Links
5. Put the bot role above normal members and above the quarantine role.
6. Copy `config.example.json` to `config.json`.
7. Set the bot token, log channel ID and optional quarantine role.
8. Run `start.bat`.

## Important safety recommendation

Keep Discord's native Safety Setup / AutoMod / explicit-media protection enabled too. This bot is intended as an additional moderation layer, not a replacement for Discord's own safety systems.

## Teaching it the screenshot you showed

Reply to a scam screenshot and run:

`!guard_hash MrBeast scam`

or attach an image to the command.

The bot stores a perceptual fingerprint in SQLite.

## Test without punishing anyone

`!guard_scan MRBEAST GIVEAWAY claim your $5000 at https://example.xyz`

The bot replies with the score and every rule that triggered.

## Tuning

Edit the thresholds in `config.json`:

```json
"thresholds": {
  "delete": 6,
  "timeout_short": 10,
  "timeout_long": 16,
  "ban": 28
}
```

For a community server, keep the ban threshold high so a compromised legitimate account is normally quarantined rather than permanently removed.

## Arbitrary NSFW images

This version detects NSFW scam wording and known scam-image fingerprints. It does not claim to perfectly classify arbitrary pornographic imagery. Discord's native explicit-media protections should stay enabled. A dedicated optional visual moderation provider can be integrated later if broader image classification is required.


## v2.1.0 — NSFW Server-Drop Protection

This update adds a dedicated detector for Discord invite drops like the one shown in the screenshot.

When a member posts a Discord invite, AntiScam can:
- resolve the invite through Discord
- inspect the target server name and description
- check the target server's exposed NSFW level when available
- check the Discord invite preview/embed text
- compare against configurable adult-server keywords
- use explicit blocked/allowed Discord guild IDs
- optionally block every external Discord invite
- delete the message and escalate to timeout through the normal score engine

Example configuration:

```json
"nsfw_server_drop_protection": {
  "enabled": true,
  "delete_any_external_discord_invite": false,
  "timeout_minutes": 1440,
  "score": 18,
  "resolve_invite_metadata": true,
  "blocked_guild_ids": [],
  "allowed_guild_ids": [],
  "adult_keywords": [
    "pornhub",
    "onlyfans",
    "18+",
    "nsfw",
    "adult content",
    "nudes",
    "leaks",
    "xxx"
  ]
}
```

With the default score of 18, a confirmed NSFW-server drop is high enough to trigger the long-timeout path in the normal v2 escalation policy.

If you want **all outside Discord server invites** removed, set:

```json
"delete_any_external_discord_invite": true
```

Use `allowed_guild_ids` for partner servers you still want members to be able to invite.
