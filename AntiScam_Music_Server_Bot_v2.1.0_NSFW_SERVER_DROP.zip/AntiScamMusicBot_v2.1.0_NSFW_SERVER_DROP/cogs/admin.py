
import io
import json
import discord
from discord.ext import commands
from PIL import Image
import imagehash

class DomainModal(discord.ui.Modal):
    def __init__(self, bot, mode):
        super().__init__(title=f"{mode.title()} Domain")
        self.bot = bot
        self.mode = mode
        self.domain = discord.ui.TextInput(
            label="Domain",
            placeholder="example.com",
            required=True,
            max_length=253
        )
        self.add_item(self.domain)

    async def on_submit(self, interaction: discord.Interaction):
        value = str(self.domain.value).lower().strip()
        value = value.replace("https://","").replace("http://","").split("/")[0]
        await self.bot.db.set_domain(interaction.guild.id, value, self.mode)
        await interaction.response.send_message(
            f"✅ `{value}` added to the **{self.mode}** list.",
            ephemeral=True
        )

class GuardPanel(discord.ui.View):
    def __init__(self, bot):
        super().__init__(timeout=600)
        self.bot = bot

    async def interaction_check(self, interaction):
        if interaction.user.guild_permissions.manage_guild:
            return True
        await interaction.response.send_message("Manage Server permission required.", ephemeral=True)
        return False

    @discord.ui.button(label="Status", emoji="🛡️", style=discord.ButtonStyle.primary)
    async def status(self, interaction, button):
        cfg = self.bot.config
        rows = await self.bot.db.recent_incidents(interaction.guild.id, 100)
        await interaction.response.send_message(
            f"**AntiScam v{cfg['version']}**\n"
            f"Incidents in latest 100 records: **{len(rows)}**\n"
            f"Delete threshold: **{cfg['thresholds']['delete']}**\n"
            f"Short timeout: **{cfg['thresholds']['timeout_short']}**\n"
            f"Long timeout: **{cfg['thresholds']['timeout_long']}**",
            ephemeral=True
        )

    @discord.ui.button(label="Allow Domain", emoji="✅", style=discord.ButtonStyle.success)
    async def allow_domain(self, interaction, button):
        await interaction.response.send_modal(DomainModal(self.bot, "allow"))

    @discord.ui.button(label="Block Domain", emoji="🚫", style=discord.ButtonStyle.danger)
    async def block_domain(self, interaction, button):
        await interaction.response.send_modal(DomainModal(self.bot, "block"))

    @discord.ui.button(label="Recent Incidents", emoji="📋", style=discord.ButtonStyle.secondary)
    async def incidents(self, interaction, button):
        rows = await self.bot.db.recent_incidents(interaction.guild.id, 10)
        if not rows:
            await interaction.response.send_message("No incidents logged yet.", ephemeral=True)
            return
        lines = []
        for r in rows:
            fp = " FP" if r["false_positive"] else ""
            lines.append(f"`{r['created_at']}` <@{r['user_id']}> score **{r['score']}** `{r['action']}`{fp}")
        await interaction.response.send_message("\n".join(lines)[:1900], ephemeral=True)

class AdminCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="guard_panel")
    @commands.has_permissions(manage_guild=True)
    async def guard_panel(self, ctx):
        embed = discord.Embed(
            title="🛡️ AntiScam Control Center",
            description=(
                "Use the buttons below to review status and tune domain protection.\n\n"
                "For scam screenshots, attach the image and run `!guard_hash [label]` "
                "or reply to the image with that command."
            )
        )
        await ctx.send(embed=embed, view=GuardPanel(self.bot))

    @commands.command(name="guard_status")
    @commands.has_permissions(manage_guild=True)
    async def guard_status(self, ctx):
        await ctx.send(
            f"✅ AntiScam **v{self.bot.config['version']}** active | "
            f"delete ≥ {self.bot.config['thresholds']['delete']} | "
            f"short timeout ≥ {self.bot.config['thresholds']['timeout_short']} | "
            f"long timeout ≥ {self.bot.config['thresholds']['timeout_long']}"
        )

    @commands.command(name="guard_scan")
    @commands.has_permissions(manage_messages=True)
    async def guard_scan(self, ctx, *, text: str):
        class Fake:
            pass
        fake = Fake()
        fake.content = text
        fake.embeds = []
        fake.attachments = []
        fake.guild = ctx.guild
        fake.author = ctx.author
        det = await self.bot.detector.scan_message(fake)
        await ctx.send(
            f"Score: **{det.score}**\n" +
            ("\n".join(f"• {r}" for r in det.reasons) if det.reasons else "No triggers.")
        )

    @commands.command(name="guard_hash")
    @commands.has_permissions(manage_guild=True)
    async def guard_hash(self, ctx, *, label: str = "known scam"):
        target = None
        if ctx.message.attachments:
            target = ctx.message.attachments[0]
        elif ctx.message.reference and isinstance(ctx.message.reference.resolved, discord.Message):
            ref = ctx.message.reference.resolved
            if ref.attachments:
                target = ref.attachments[0]

        if not target:
            await ctx.send("Attach an image or reply to a message with an image.")
            return

        try:
            data = await target.read()
            img = Image.open(io.BytesIO(data)).convert("RGB")
            h = str(imagehash.phash(img))
        except Exception:
            await ctx.send("I could not read that image.")
            return

        await self.bot.db.add_image_hash(ctx.guild.id, h, label[:120])
        await ctx.send(f"✅ Saved image fingerprint `{h}` as **{label[:120]}**.")

    @commands.command(name="guard_unhash")
    @commands.has_permissions(manage_guild=True)
    async def guard_unhash(self, ctx, hash_value: str):
        await self.bot.db.remove_image_hash(ctx.guild.id, hash_value)
        await ctx.send("✅ Removed the image fingerprint if it existed.")

    @commands.command(name="guard_incidents")
    @commands.has_permissions(manage_messages=True)
    async def guard_incidents(self, ctx):
        rows = await self.bot.db.recent_incidents(ctx.guild.id, 15)
        if not rows:
            await ctx.send("No incidents.")
            return
        lines = [
            f"`{r['created_at']}` <@{r['user_id']}> score **{r['score']}** — {r['action']}"
            for r in rows
        ]
        await ctx.send("\n".join(lines)[:1900])

async def setup(bot):
    await bot.add_cog(AdminCog(bot))
