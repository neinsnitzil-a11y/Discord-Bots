
import discord

class IncidentView(discord.ui.View):
    def __init__(self, bot, guild_id: int, user_id: int, message_id: int):
        super().__init__(timeout=86400)
        self.bot = bot
        self.guild_id = guild_id
        self.user_id = user_id
        self.message_id = message_id

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        perms = interaction.user.guild_permissions
        if perms.manage_messages or perms.moderate_members or perms.administrator:
            return True
        await interaction.response.send_message("Moderator permission required.", ephemeral=True)
        return False

    @discord.ui.button(label="Release Timeout", style=discord.ButtonStyle.success, emoji="🔓")
    async def release(self, interaction: discord.Interaction, button: discord.ui.Button):
        guild = interaction.guild
        member = guild.get_member(self.user_id)
        if not member:
            await interaction.response.send_message("Member is no longer in the server.", ephemeral=True)
            return
        try:
            await member.timeout(None, reason=f"Released by {interaction.user}")
            await interaction.response.send_message(f"Released {member.mention}.", ephemeral=True)
        except discord.Forbidden:
            await interaction.response.send_message("I cannot modify that member.", ephemeral=True)

    @discord.ui.button(label="Mark False Positive", style=discord.ButtonStyle.secondary, emoji="✅")
    async def false_positive(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.bot.db.mark_false_positive(self.guild_id, self.message_id)
        await interaction.response.send_message("Marked as a false positive.", ephemeral=True)

    @discord.ui.button(label="Ban Account", style=discord.ButtonStyle.danger, emoji="⛔")
    async def ban(self, interaction: discord.Interaction, button: discord.ui.Button):
        guild = interaction.guild
        member = guild.get_member(self.user_id)
        if not member:
            await interaction.response.send_message("Member is no longer in the server.", ephemeral=True)
            return
        try:
            await member.ban(reason=f"Anti-scam moderator action by {interaction.user}", delete_message_seconds=0)
            await interaction.response.send_message(f"Banned {member}.", ephemeral=True)
        except discord.Forbidden:
            await interaction.response.send_message("I cannot ban that member.", ephemeral=True)
