
from dataclasses import dataclass, field
from collections import defaultdict, deque
from datetime import datetime, timezone
import io
import time

from PIL import Image
import imagehash
import re

DISCORD_INVITE_RE = re.compile(r'(?:https?://)?(?:www\.)?(?:discord\.gg|discord(?:app)?\.com/invite)/([A-Za-z0-9-]+)', re.I)

from .utils import normalize_text, extract_urls, host_from_url, domain_matches, MONEY_RE, sha256_text

@dataclass
class Detection:
    score: int = 0
    reasons: list[str] = field(default_factory=list)

    def add(self, points: int, reason: str):
        if points:
            self.score += int(points)
            self.reasons.append(reason)

class Detector:
    def __init__(self, config, db):
        self.config = config
        self.db = db
        self.user_windows = defaultdict(deque)
        self.message_campaign = defaultdict(lambda: defaultdict(deque))

    async def scan_message(self, message):
        d = Detection()
        text_parts = [message.content or ""]

        for e in message.embeds:
            for item in (e.title, e.description, getattr(e.author, "name", None), getattr(e.footer, "text", None)):
                if item:
                    text_parts.append(item)

        text = "\n".join(text_parts)
        norm = normalize_text(text)
        urls = extract_urls(text)

        weights = self.config["weights"]
        for group, phrases in self.config["phrase_groups"].items():
            for phrase in phrases:
                if normalize_text(phrase) in norm:
                    d.add(weights["phrase"], f"{group} phrase: {phrase}")

        await self._scan_urls(message.guild.id, urls, norm, d)
        await self._scan_account_risk(message, d)
        await self._scan_rate_and_campaign(message, norm, d)
        await self._scan_attachments(message, d)
        await self._scan_nsfw_server_drops(message, text, d)

        prior = await self.db.user_incident_count(message.guild.id, message.author.id, 30)
        if prior:
            d.add(min(prior, 3) * weights["repeat_offender"], f"repeat offender: {prior} prior incident(s)")

        return d

    async def _scan_urls(self, guild_id, urls, norm, d):
        cfg = self.config["url_protection"]
        if not cfg.get("enabled", True):
            return

        overrides = await self.db.get_domains(guild_id)
        allow = list(cfg["allow_domains"])
        block = list(cfg["block_domains"])
        for domain, mode in overrides:
            (allow if mode == "allow" else block).append(domain)

        for url in urls:
            host = host_from_url(url)
            if not host:
                continue

            if any(domain_matches(host, x) for x in block):
                d.add(self.config["weights"]["blocked_domain"], f"blocked domain: {host}")
                continue

            if any(domain_matches(host, x) for x in allow):
                continue

            d.add(self.config["weights"]["external_domain"], f"unrecognized domain: {host}")

            if any(host.endswith(tld) for tld in cfg["suspicious_tlds"]):
                d.add(self.config["weights"]["suspicious_tld"], f"suspicious TLD: {host}")

            if any(domain_matches(host, x) for x in cfg["shorteners"]):
                d.add(self.config["weights"]["shortener"], f"URL shortener: {host}")

            if cfg.get("flag_punycode") and "xn--" in host:
                d.add(self.config["weights"]["punycode"], f"punycode domain: {host}")

        if urls and ("mrbeast" in norm or "mr beast" in norm):
            d.add(self.config["weights"]["brand_plus_link"], "MrBeast/brand lure combined with link")

        if urls and any(x in norm for x in ("link in my bio", "check my bio", "join the link in my bio")):
            d.add(self.config["weights"]["bio_plus_link"], "bio lure combined with link")

        if MONEY_RE.search(norm) and any(x in norm for x in ("giveaway","won","bonus","claim","withdraw")):
            d.add(self.config["weights"]["money_lure"], "large-money giveaway language")

    async def _scan_account_risk(self, message, d):
        cfg = self.config["account_risk"]
        if not cfg.get("enabled", True):
            return

        now = datetime.now(timezone.utc)
        age_days = (now - message.author.created_at).days
        if age_days < int(cfg["new_account_days"]):
            d.add(int(cfg["new_account_score"]), f"new Discord account: {age_days} day(s) old")

        if getattr(message.author, "joined_at", None):
            joined_hours = (now - message.author.joined_at).total_seconds() / 3600
            if joined_hours < int(cfg["new_member_hours"]):
                d.add(int(cfg["new_member_score"]), f"new server member: {joined_hours:.1f}h")

    async def _scan_rate_and_campaign(self, message, norm, d):
        cfg = self.config["raid_protection"]
        if not cfg.get("enabled", True):
            return

        now = time.monotonic()
        key = (message.guild.id, message.author.id)
        q = self.user_windows[key]
        q.append(now)
        window = int(cfg["window_seconds"])
        while q and now - q[0] > window:
            q.popleft()
        if len(q) >= int(cfg["messages_per_window"]):
            d.add(int(cfg["score"]), f"rapid-message burst: {len(q)} in {window}s")

        if norm:
            digest = sha256_text(norm)
            cq = self.message_campaign[message.guild.id][digest]
            cq.append((now, message.author.id))
            cwin = int(cfg["duplicate_campaign_window_seconds"])
            while cq and now - cq[0][0] > cwin:
                cq.popleft()
            distinct = len({uid for _, uid in cq})
            if distinct >= int(cfg["duplicate_campaign_users"]):
                d.add(int(cfg["score"]), f"duplicate spam campaign across {distinct} users")

    async def _scan_attachments(self, message, d):
        if not self.config["image_protection"].get("enabled", True):
            return

        stored = await self.db.image_hashes(message.guild.id)
        threshold = int(self.config["image_protection"]["hash_distance"])

        for a in message.attachments:
            name_norm = normalize_text(a.filename)
            for group, phrases in self.config["phrase_groups"].items():
                for phrase in phrases:
                    if normalize_text(phrase) in name_norm:
                        d.add(self.config["weights"]["phrase"], f"suspicious attachment filename: {a.filename}")

            if not (a.content_type or "").startswith("image/"):
                continue
            try:
                data = await a.read()
                img = Image.open(io.BytesIO(data)).convert("RGB")
                current = imagehash.phash(img)
                for h, label in stored:
                    try:
                        dist = current - imagehash.hex_to_hash(h)
                        if dist <= threshold:
                            d.add(self.config["weights"]["known_bad_image"], f"known scam image: {label} (distance {dist})")
                            break
                    except Exception:
                        pass
            except Exception:
                pass
