
import re
import unicodedata
from urllib.parse import urlparse

URL_RE = re.compile(r'https?://[^\s<>()\]\}]+', re.I)
MONEY_RE = re.compile(r'\$\s?(?:[1-9]\d{2,}|[1-9]\d?(?:,\d{3})+)', re.I)
ZERO_WIDTH = re.compile(r'[\u200B-\u200D\u2060\uFEFF]')

LEET = str.maketrans({
    "0":"o","1":"i","3":"e","4":"a","5":"s","7":"t","8":"b","$":"s"
})

def normalize_text(text: str) -> str:
    text = text or ""
    text = ZERO_WIDTH.sub("", text)
    text = unicodedata.normalize("NFKC", text)
    text = text.lower().translate(LEET)
    text = re.sub(r'[\s\-_\.]+', ' ', text)
    return re.sub(r'\s+', ' ', text).strip()

def extract_urls(text: str):
    return URL_RE.findall(text or "")

def host_from_url(url: str) -> str:
    try:
        host = (urlparse(url).hostname or "").lower().rstrip(".")
        if host.startswith("www."):
            host = host[4:]
        return host
    except Exception:
        return ""

def domain_matches(host: str, domain: str) -> bool:
    host = (host or "").lower()
    domain = (domain or "").lower()
    return host == domain or host.endswith("." + domain)

def sha256_text(text: str) -> str:
    import hashlib
    return hashlib.sha256(normalize_text(text).encode("utf-8", "ignore")).hexdigest()
