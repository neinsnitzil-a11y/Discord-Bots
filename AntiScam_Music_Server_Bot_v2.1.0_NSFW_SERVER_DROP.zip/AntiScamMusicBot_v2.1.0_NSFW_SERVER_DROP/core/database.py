
import aiosqlite
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS incidents(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    channel_id INTEGER NOT NULL,
    message_id INTEGER NOT NULL,
    score INTEGER NOT NULL,
    action TEXT NOT NULL,
    reasons TEXT NOT NULL,
    content TEXT,
    false_positive INTEGER NOT NULL DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_incidents_guild_user
ON incidents(guild_id, user_id);

CREATE TABLE IF NOT EXISTS domain_overrides(
    guild_id INTEGER NOT NULL,
    domain TEXT NOT NULL,
    mode TEXT NOT NULL CHECK(mode IN ('allow','block')),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY(guild_id, domain)
);

CREATE TABLE IF NOT EXISTS image_hashes(
    guild_id INTEGER NOT NULL,
    hash TEXT NOT NULL,
    label TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY(guild_id, hash)
);
"""

class Database:
    def __init__(self, path: Path):
        self.path = path

    async def init(self):
        async with aiosqlite.connect(self.path) as db:
            await db.executescript(SCHEMA)
            await db.commit()

    async def add_incident(self, guild_id, user_id, channel_id, message_id, score, action, reasons, content):
        async with aiosqlite.connect(self.path) as db:
            await db.execute(
                """INSERT INTO incidents
                (guild_id,user_id,channel_id,message_id,score,action,reasons,content)
                VALUES(?,?,?,?,?,?,?,?)""",
                (guild_id,user_id,channel_id,message_id,score,action,reasons,content[:4000])
            )
            await db.commit()

    async def recent_incidents(self, guild_id, limit=20):
        async with aiosqlite.connect(self.path) as db:
            db.row_factory = aiosqlite.Row
            cur = await db.execute(
                "SELECT * FROM incidents WHERE guild_id=? ORDER BY id DESC LIMIT ?",
                (guild_id, limit)
            )
            return await cur.fetchall()

    async def user_incident_count(self, guild_id, user_id, days=30):
        async with aiosqlite.connect(self.path) as db:
            cur = await db.execute(
                """SELECT COUNT(*) FROM incidents
                WHERE guild_id=? AND user_id=? AND false_positive=0
                AND created_at >= datetime('now', ?)""",
                (guild_id, user_id, f"-{int(days)} days")
            )
            row = await cur.fetchone()
            return int(row[0] if row else 0)

    async def mark_false_positive(self, guild_id, message_id):
        async with aiosqlite.connect(self.path) as db:
            await db.execute(
                "UPDATE incidents SET false_positive=1 WHERE guild_id=? AND message_id=?",
                (guild_id, message_id)
            )
            await db.commit()

    async def set_domain(self, guild_id, domain, mode):
        domain = domain.lower().strip()
        async with aiosqlite.connect(self.path) as db:
            await db.execute(
                """INSERT INTO domain_overrides(guild_id,domain,mode)
                VALUES(?,?,?)
                ON CONFLICT(guild_id,domain) DO UPDATE SET mode=excluded.mode""",
                (guild_id, domain, mode)
            )
            await db.commit()

    async def get_domains(self, guild_id):
        async with aiosqlite.connect(self.path) as db:
            cur = await db.execute(
                "SELECT domain,mode FROM domain_overrides WHERE guild_id=?",
                (guild_id,)
            )
            return await cur.fetchall()

    async def add_image_hash(self, guild_id, hash_value, label="known scam"):
        async with aiosqlite.connect(self.path) as db:
            await db.execute(
                """INSERT OR IGNORE INTO image_hashes(guild_id,hash,label)
                VALUES(?,?,?)""",
                (guild_id, hash_value, label)
            )
            await db.commit()

    async def remove_image_hash(self, guild_id, hash_value):
        async with aiosqlite.connect(self.path) as db:
            await db.execute(
                "DELETE FROM image_hashes WHERE guild_id=? AND hash=?",
                (guild_id, hash_value)
            )
            await db.commit()

    async def image_hashes(self, guild_id):
        async with aiosqlite.connect(self.path) as db:
            cur = await db.execute(
                "SELECT hash,label FROM image_hashes WHERE guild_id=?",
                (guild_id,)
            )
            return await cur.fetchall()
