@echo off
title AntiScam Music Server Bot v2.0.0
cd /d "%~dp0"

where py >nul 2>nul
if errorlevel 1 (
  echo Python launcher not found.
  echo Install Python 3.12 and enable "Add Python to PATH".
  pause
  exit /b 1
)

py -3.12 --version >nul 2>nul
if errorlevel 1 (
  echo Python 3.12 is required.
  pause
  exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
  py -3.12 -m venv .venv
)

call ".venv\Scripts\activate.bat"
python -m pip install --upgrade pip
pip install -r requirements.txt

if not exist "config.json" (
  copy /Y "config.example.json" "config.json" >nul
  echo.
  echo Created config.json. Edit it and add your token/settings.
  pause
  exit /b 0
)

python bot.py
pause
