
import json
import logging
from pathlib import Path
from datetime import timedelta

import discord
from discord.ext import commands

from core.database import Database
from core.detector import Detector
from core.modview import IncidentView

BASE = Path(__file__).resolve().parent
CONFIG_PATH = BASE / "config.json"

if not CONFIG_PATH.exists():
    raise SystemExit("config.json is missing. Copy config.example.json to config.json.")

config = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s"
)
log = logging.getLogger("antiscam")

intents = discord.Intents.default()
intents.message_content = True
intents.members = True

class AntiScamBot(commands.Bot):
    def __init__(self):
        super().__init__(command_prefix=config.get("prefix","!"), intents=intents, help_command=None)
        self.config = config
        self.db = Database(BASE / "antiscam.db")
        self.detector = Detector(config, self.db)

    async def setup_hook(self):
        await self.db.init()
        await self.load_extension("cogs.admin")

bot = AntiScamBot()

def is_mod(member: discord.Member):
    if member.guild_permissions.administrator or member.guild_permissions.manage_messages:
        return True
    allowed = {int(x) for x in config.get("moderator_role_ids", [])}
    return any(r.id in allowed for r in member.roles)

async def log_incident(message, det, action):
    channel_id = int(config.get("log_channel_id") or 0)
    channel = message.guild.get_channel(channel_id) if channel_id else None
    if not channel:
        return

    embed = discord.Embed(
        title="🚨 AntiScam Incident",
        description=f"**Score:** {det.score}\n**Action:** {action}",
        timestamp=discord.utils.utcnow()
    )
    embed.add_field(name="User", value=f"{message.author} (`{message.author.id}`)", inline=False)
    embed.add_field(name="Channel", value=message.channel.mention, inline=True)
    embed.add_field(name="Message ID", value=str(message.id), inline=True)
    embed.add_field(name="Reasons", value="\n".join(f"• {r}" for r in det.reasons)[:1000] or "Unknown", inline=False)
    if message.content:
        embed.add_field(name="Content", value=message.content[:1000], inline=False)

    view = IncidentView(bot, message.guild.id, message.author.id, message.id)
    await channel.send(embed=embed, view=view)

async def dm_user(member, action, reasons):
    if not config.get("dm_punished_users", True):
        return
    try:
        await member.send(
            "🛡️ **Your account triggered this server's anti-scam protection.**\n\n"
            f"Action: **{action}**\n"
            f"Reason: {reasons[:900]}\n\n"
            "If your account was compromised, change your Discord password, enable 2FA, "
            "remove unknown authorized apps/sessions, and contact the server moderators."
        )
    except Exception:
        pass

async def apply_action(message, det):
    t = config["thresholds"]
    action = "log only"

    if det.score >= int(t["ban"]):
        action = "ban"
    elif det.score >= int(t["timeout_long"]):
        action = f"timeout {config['timeouts']['long_minutes']}m"
    elif det.score >= int(t["timeout_short"]):
        action = f"timeout {config['timeouts']['short_minutes']}m"
    elif det.score >= int(t["delete"]):
        action = "delete"

    if action == "log only":
        return False

    if config.get("delete_detected_messages", True):
        try:
            await message.delete()
        except (discord.NotFound, discord.Forbidden):
            pass

    member = message.author
    if action == "ban":
        try:
            await member.ban(reason="High-confidence anti-scam detection", delete_message_seconds=0)
        except discord.Forbidden:
            action += " (failed: permissions)"
    elif action.startswith("timeout"):
        minutes = int(action.split()[1].rstrip("m"))
        try:
            await member.timeout(
                discord.utils.utcnow() + timedelta(minutes=minutes),
                reason="Anti-scam quarantine"
            )
        except discord.Forbidden:
            action += " (failed: permissions)"

    quarantine = int(config.get("quarantine_role_id") or 0)
    if quarantine and isinstance(member, discord.Member):
        role = message.guild.get_role(quarantine)
        if role:
            try:
                await member.add_roles(role, reason="Anti-scam quarantine")
            except discord.Forbidden:
                pass

    reasons = "; ".join(dict.fromkeys(det.reasons))
    await bot.db.add_incident(
        message.guild.id, member.id, message.channel.id, message.id,
        det.score, action, reasons, message.content or ""
    )
    await log_incident(message, det, action)
    await dm_user(member, action, reasons)
    return True

@bot.event
async def on_ready():
    log.info("Logged in as %s (%s)", bot.user, bot.user.id)
    log.info("AntiScam v%s watching %s guild(s)", config["version"], len(bot.guilds))

@bot.event
async def on_message(message: discord.Message):
    if not message.guild:
        return
    if config.get("ignore_bots", True) and message.author.bot:
        return
    if config.get("ignore_moderators", True) and isinstance(message.author, discord.Member) and is_mod(message.author):
        await bot.process_commands(message)
        return

    try:
        det = await bot.detector.scan_message(message)
        acted = await apply_action(message, det)
        if acted:
            return
    except Exception:
        log.exception("Detection failure")

    await bot.process_commands(message)

@bot.command(name="guard_help")
async def guard_help(ctx):
    await ctx.send(
        "**AntiScam v2 Commands**\n"
        "`!guard_panel` — interactive admin panel\n"
        "`!guard_status` — status\n"
        "`!guard_scan <text>` — test text without punishment\n"
        "`!guard_hash [label]` — fingerprint attached/replied scam image\n"
        "`!guard_unhash <hash>` — remove fingerprint\n"
        "`!guard_incidents` — recent incidents"
    )

token = config.get("token", "")
if not token or token == "PUT_BOT_TOKEN_HERE":
    raise SystemExit("Put your bot token in config.json.")
bot.run(token)
