
import os, json, aiohttp, discord
from discord.ext import commands

TOKEN = os.getenv("DISCORD_TOKEN", "")
PREFIX = "!"

intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix=PREFIX, intents=intents)

ANILIST_URL = "https://graphql.anilist.co"

QUERY = """
query ($search: String, $page: Int) {
  Page(page: $page, perPage: 10) {
    media(search: $search, type: ANIME, sort: SEARCH_MATCH) {
      id
      title { romaji english native }
      description(asHtml: false)
      episodes
      status
      seasonYear
      genres
      siteUrl
      coverImage { large }
      streamingEpisodes { title url site }
    }
  }
}
"""

async def search_anime(term, page=1):
    async with aiohttp.ClientSession() as s:
        async with s.post(ANILIST_URL, json={"query": QUERY, "variables": {"search": term, "page": page}}) as r:
            r.raise_for_status()
            data = await r.json()
            return data["data"]["Page"]["media"]

class AnimeSelect(discord.ui.Select):
    def __init__(self, results):
        self.results = results
        opts = []
        for i, a in enumerate(results[:10]):
            title = a["title"].get("english") or a["title"].get("romaji") or "Unknown"
            opts.append(discord.SelectOption(label=title[:100], value=str(i), description=f"{a.get('seasonYear') or '?'} • {a.get('episodes') or '?'} eps"))
        super().__init__(placeholder="Choose an anime…", min_values=1, max_values=1, options=opts)

    async def callback(self, interaction):
        a = self.results[int(self.values[0])]
        title = a["title"].get("english") or a["title"].get("romaji") or "Unknown"
        desc = (a.get("description") or "No description available.").replace("<br>","\n")
        embed = discord.Embed(title=title, description=desc[:3800], url=a.get("siteUrl"))
        embed.add_field(name="Episodes", value=str(a.get("episodes") or "Unknown"))
        embed.add_field(name="Status", value=str(a.get("status") or "Unknown"))
        embed.add_field(name="Year", value=str(a.get("seasonYear") or "Unknown"))
        genres = ", ".join(a.get("genres") or [])
        if genres:
            embed.add_field(name="Genres", value=genres[:1024], inline=False)
        if a.get("coverImage",{}).get("large"):
            embed.set_thumbnail(url=a["coverImage"]["large"])
        legal = [e for e in (a.get("streamingEpisodes") or []) if e.get("url")]
        if legal:
            links = "\n".join(f"[{e.get('site','Watch')} — {e.get('title','Episode')}]({e['url']})" for e in legal[:8])
            embed.add_field(name="Official / indexed streaming links", value=links[:1024], inline=False)
        else:
            embed.add_field(name="Streaming", value="No official streaming links were returned by AniList.", inline=False)
        await interaction.response.send_message(embed=embed, ephemeral=True)

class AnimeView(discord.ui.View):
    def __init__(self, results):
        super().__init__(timeout=180)
        self.add_item(AnimeSelect(results))

class SearchModal(discord.ui.Modal, title="Search Anime"):
    term = discord.ui.TextInput(label="Anime title", placeholder="Attack on Titan")
    async def on_submit(self, interaction):
        await interaction.response.defer(ephemeral=True)
        results = await search_anime(str(self.term.value))
        if not results:
            await interaction.followup.send("No results found.", ephemeral=True)
            return
        await interaction.followup.send("Select a result:", view=AnimeView(results), ephemeral=True)

class MainView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
    @discord.ui.button(label="Search Anime", emoji="🔎", style=discord.ButtonStyle.primary, custom_id="anime:search")
    async def search(self, interaction, button):
        await interaction.response.send_modal(SearchModal())

@bot.event
async def on_ready():
    bot.add_view(MainView())
    print(f"Anime Search Bot ready as {bot.user}")

@bot.command()
async def anime(ctx):
    embed = discord.Embed(title="🎌 Anime Search", description="Search AniList metadata and open official/indexed streaming links.")
    await ctx.send(embed=embed, view=MainView())

if not TOKEN:
    raise SystemExit("Set DISCORD_TOKEN environment variable.")
bot.run(TOKEN)
