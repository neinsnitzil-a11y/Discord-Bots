@echo off
cd /d "%~dp0"
py -3.12 -m venv .venv 2>nul
call .venv\Scripts\activate.bat
pip install -r requirements.txt
if "%DISCORD_TOKEN%"=="" (
  echo Set DISCORD_TOKEN first.
  echo Example PowerShell: $env:DISCORD_TOKEN="YOUR_TOKEN"
  pause
  exit /b 1
)
python bot.py
pause
