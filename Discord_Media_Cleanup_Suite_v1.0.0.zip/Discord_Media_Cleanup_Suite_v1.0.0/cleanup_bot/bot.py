
import os, json, time, discord
from discord.ext import commands
from datetime import datetime, timezone, timedelta

TOKEN = os.getenv("DISCORD_TOKEN","")
PREFIX = "!"
DATA_FILE = "cleanup_state.json"

intents = discord.Intents.default()
intents.members = True
intents.message_content = True
bot = commands.Bot(command_prefix=PREFIX, intents=intents)

def load_state():
    try:
        with open(DATA_FILE,"r",encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {"channel_activity":{}}

def save_state(s):
    with open(DATA_FILE,"w",encoding="utf-8") as f:
        json.dump(s,f,indent=2)

state = load_state()

def is_admin(member):
    return member.guild_permissions.manage_guild or member.guild_permissions.administrator

@bot.event
async def on_message(message):
    if message.guild and not message.author.bot:
        state["channel_activity"][str(message.channel.id)] = datetime.now(timezone.utc).isoformat()
        save_state(state)
    await bot.process_commands(message)

class CleanupPreviewView(discord.ui.View):
    def __init__(self, bot, guild, unused_roles, unused_channels):
        super().__init__(timeout=300)
        self.bot = bot
        self.guild = guild
        self.unused_roles = unused_roles
        self.unused_channels = unused_channels

    async def interaction_check(self, interaction):
        if is_admin(interaction.user):
            return True
        await interaction.response.send_message("Manage Server permission required.", ephemeral=True)
        return False

    @discord.ui.button(label="Delete Unused Roles", style=discord.ButtonStyle.danger, emoji="🏷️")
    async def delete_roles(self, interaction, button):
        await interaction.response.defer(ephemeral=True)
        deleted = 0
        for role in self.unused_roles:
            try:
                if role.is_default() or role.managed:
                    continue
                await role.delete(reason=f"Cleanup approved by {interaction.user}")
                deleted += 1
            except Exception:
                pass
        await interaction.followup.send(f"Deleted **{deleted}** unused roles.", ephemeral=True)

    @discord.ui.button(label="Delete Unused Channels", style=discord.ButtonStyle.danger, emoji="🗑️")
    async def delete_channels(self, interaction, button):
        await interaction.response.defer(ephemeral=True)
        deleted = 0
        for ch in self.unused_channels:
            try:
                await ch.delete(reason=f"Cleanup approved by {interaction.user}")
                deleted += 1
            except Exception:
                pass
        await interaction.followup.send(f"Deleted **{deleted}** unused channels.", ephemeral=True)

class ScanModal(discord.ui.Modal, title="Scan Unused Server Items"):
    inactive_days = discord.ui.TextInput(label="Channel inactivity days", default="60")
    min_role_members = discord.ui.TextInput(label="Role member threshold", default="0")

    def __init__(self, bot):
        super().__init__()
        self.bot = bot

    async def on_submit(self, interaction):
        try:
            days = max(1,int(str(self.inactive_days.value)))
            role_limit = max(0,int(str(self.min_role_members.value)))
        except ValueError:
            await interaction.response.send_message("Use whole numbers.", ephemeral=True)
            return

        guild = interaction.guild
        unused_roles = [
            r for r in guild.roles
            if not r.is_default() and not r.managed and len(r.members) <= role_limit
        ]

        cutoff = datetime.now(timezone.utc) - timedelta(days=days)
        unused_channels = []
        for ch in guild.text_channels:
            raw = state["channel_activity"].get(str(ch.id))
            if not raw:
                # Unknown history: do not auto-classify as unused.
                continue
            try:
                last = datetime.fromisoformat(raw)
            except Exception:
                continue
            if last < cutoff:
                unused_channels.append(ch)

        role_lines = "\n".join(f"• {r.name} ({len(r.members)} members)" for r in unused_roles[:20]) or "None"
        ch_lines = "\n".join(f"• #{c.name}" for c in unused_channels[:20]) or "None"

        embed = discord.Embed(title="🧹 Cleanup Preview", description="Nothing is deleted until you press a confirmation button.")
        embed.add_field(name=f"Unused roles ({len(unused_roles)})", value=role_lines[:1024], inline=False)
        embed.add_field(name=f"Inactive channels ({len(unused_channels)})", value=ch_lines[:1024], inline=False)
        await interaction.response.send_message(
            embed=embed,
            view=CleanupPreviewView(self.bot, guild, unused_roles, unused_channels),
            ephemeral=True
        )

class CleanupView(discord.ui.View):
    def __init__(self, bot):
        super().__init__(timeout=None)
        self.bot = bot
    @discord.ui.button(label="Scan Server", emoji="🔎", style=discord.ButtonStyle.primary, custom_id="cleanup:scan")
    async def scan(self, interaction, button):
        if not is_admin(interaction.user):
            await interaction.response.send_message("Manage Server permission required.", ephemeral=True)
            return
        await interaction.response.send_modal(ScanModal(self.bot))

@bot.event
async def on_ready():
    bot.add_view(CleanupView(bot))
    print(f"Cleanup Bot ready as {bot.user}")

@bot.command()
@commands.has_permissions(manage_guild=True)
async def cleanup(ctx):
    embed = discord.Embed(
        title="🧹 Server Cleanup Manager",
        description="Preview unused roles and inactive channels. Deletions always require confirmation."
    )
    await ctx.send(embed=embed, view=CleanupView(bot))

if not TOKEN:
    raise SystemExit("Set DISCORD_TOKEN environment variable.")
bot.run(TOKEN)
