
import os, re, discord
from discord.ext import commands

TOKEN = os.getenv("DISCORD_TOKEN","")
PREFIX = "!"

intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix=PREFIX, intents=intents)

ALLOWED_SCHEMES = ("https://","http://")

class StartWatchModal(discord.ui.Modal, title="Start Watch Party"):
    title_in = discord.ui.TextInput(label="Title", placeholder="Movie / episode / video title")
    url_in = discord.ui.TextInput(label="Licensed or owned media URL", placeholder="https://...")
    note_in = discord.ui.TextInput(label="Notes", required=False, placeholder="Starts at 8 PM")

    async def on_submit(self, interaction):
        url = str(self.url_in.value).strip()
        if not url.startswith(ALLOWED_SCHEMES):
            await interaction.response.send_message("Please use a normal http/https URL.", ephemeral=True)
            return
        embed = discord.Embed(
            title=f"🎬 Watch Party: {self.title_in.value}",
            description=(str(self.note_in.value) or "Use the button below to open the media."),
            url=url
        )
        view = discord.ui.View()
        view.add_item(discord.ui.Button(label="Open Media", url=url, emoji="▶️"))
        await interaction.response.send_message(embed=embed, view=view)

class WatchView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
    @discord.ui.button(label="Start Watch Party", emoji="🎬", style=discord.ButtonStyle.primary, custom_id="watch:start")
    async def start_watch(self, interaction, button):
        await interaction.response.send_modal(StartWatchModal())

@bot.event
async def on_ready():
    bot.add_view(WatchView())
    print(f"Watch Party Bot ready as {bot.user}")

@bot.command()
async def watchparty(ctx):
    embed = discord.Embed(
        title="🎬 Media Watch Party",
        description="Create a watch-party card for media you own or are authorized to share."
    )
    await ctx.send(embed=embed, view=WatchView())

if not TOKEN:
    raise SystemExit("Set DISCORD_TOKEN environment variable.")
bot.run(TOKEN)
