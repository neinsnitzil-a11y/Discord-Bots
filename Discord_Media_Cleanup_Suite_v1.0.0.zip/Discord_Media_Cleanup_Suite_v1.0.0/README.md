
# Discord Media + Cleanup Suite v1.0.0

This package contains three GUI-based Discord bots:

## 1. Anime Search Bot
Searches AniList metadata from a Discord modal/select GUI and surfaces official/indexed streaming links returned by AniList.

Command to post the GUI:
`!anime`

## 2. Media Watch Party Bot
Creates GUI watch-party cards for media URLs you own or are authorized to share.

Command:
`!watchparty`

This intentionally does not rip YouTube audio or redistribute movies.

## 3. Server Cleanup Bot
Finds unused roles and inactive channels, shows a preview, and requires an admin confirmation button before deletion.

Command:
`!cleanup`

### Cleanup safety
- managed roles are never deleted
- @everyone is never deleted
- channels with unknown activity history are not considered unused
- deletions are previewed first
- only Manage Server/admin users can approve cleanup

## Setup
Each bot is independent.

1. Install Python 3.12.
2. Create a Discord bot application for each service, or run them one at a time with different tokens.
3. Enable intents as needed:
   - Anime: Message Content
   - Watch Party: Message Content
   - Cleanup: Message Content + Server Members
4. Set the token before launch:

Windows PowerShell:
`$env:DISCORD_TOKEN="YOUR_TOKEN"; python bot.py`

5. Install requirements from the bot's folder:
`pip install -r requirements.txt`

## Permissions
Anime Search:
- View Channels
- Send Messages
- Embed Links

Watch Party:
- View Channels
- Send Messages
- Embed Links

Cleanup:
- View Channels
- Send Messages
- Manage Roles
- Manage Channels
- Manage Server
