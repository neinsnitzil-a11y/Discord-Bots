@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
 echo Python launcher not found. Install Python 3.12 first from python.org and enable Add Python to PATH.
 pause
 exit /b 1
)
py -3.12 -m venv .venv
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt
if not exist .env copy .env.example .env
where ffmpeg >nul 2>nul
if errorlevel 1 (
 echo.
 echo FFmpeg was not found in PATH.
 where winget >nul 2>nul
 if not errorlevel 1 (
   echo Attempting FFmpeg installation with winget...
   winget install --id Gyan.FFmpeg -e --accept-source-agreements --accept-package-agreements
 ) else (
   echo Install FFmpeg manually and either add it to PATH or set FFMPEG_PATH in .env.
 )
)
echo.
echo Install complete. MediaMTX will download automatically on first launch.
echo Edit .env with your Discord token, then run run.bat
pause
