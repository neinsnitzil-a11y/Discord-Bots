from __future__ import annotations
import threading, time
from datetime import datetime, timezone

class EventScheduler:
    def __init__(self, app):
        self.app=app; self._stop=threading.Event(); self.thread=None

    def start(self):
        if self.thread and self.thread.is_alive(): return
        self.thread=threading.Thread(target=self._run,daemon=True,name="event-scheduler"); self.thread.start()

    def stop(self): self._stop.set()

    def _parse(self, s):
        # ISO-8601. Naive timestamps are interpreted as local machine time.
        dt=datetime.fromisoformat(s.replace("Z","+00:00"))
        if dt.tzinfo is None: dt=dt.astimezone()
        return dt.astimezone(timezone.utc)

    def _run(self):
        while not self._stop.wait(2):
            now=datetime.now(timezone.utc)
            for e in self.app.db.pending_events():
                try: due=self._parse(e["scheduled_at"])
                except Exception:
                    self.app.db.mark_event_fired(e["id"], now.isoformat()); continue
                if due <= now:
                    if e["action"]=="stop": self.app.engine.stop(f"scheduler:{e['title']}")
                    else: self.app.engine.start(f"scheduler:{e['title']}")
                    self.app.db.mark_event_fired(e["id"], now.isoformat())
