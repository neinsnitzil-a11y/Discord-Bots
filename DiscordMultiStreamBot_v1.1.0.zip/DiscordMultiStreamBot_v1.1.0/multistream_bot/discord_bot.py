from __future__ import annotations
import os
from datetime import datetime, timezone
import discord
from discord.ext import commands

class ScheduleModal(discord.ui.Modal,title="Schedule Stream Action"):
    event_title=discord.ui.TextInput(label="Event name",default="Scheduled stream",max_length=100)
    when=discord.ui.TextInput(label="Start time (ISO 8601)",placeholder="2026-10-01T20:00:00-04:00")
    action=discord.ui.TextInput(label="Action",default="start",placeholder="start or stop",max_length=5)
    def __init__(self,app): super().__init__(); self.app=app
    async def on_submit(self,interaction:discord.Interaction):
        try:
            dt=datetime.fromisoformat(str(self.when).replace("Z","+00:00"))
            if dt.tzinfo is None: dt=dt.astimezone()
            act=str(self.action).strip().lower()
            if act not in {"start","stop"}: raise ValueError("Action must be start or stop")
            eid=self.app.db.add_event(str(self.event_title),dt.isoformat(),act,str(interaction.user),datetime.now(timezone.utc).isoformat())
            await interaction.response.send_message(f"Scheduled event #{eid} for `{dt.isoformat()}` ({act}).",ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"Could not schedule event: {e}",ephemeral=True)

class StreamControlView(discord.ui.View):
    def __init__(self,app): super().__init__(timeout=None); self.app=app
    async def guard(self,interaction):
        role_name=self.app.cfg.get("discord_admin_role",os.getenv("DISCORD_ADMIN_ROLE","Stream Admin"))
        ok=interaction.user.guild_permissions.administrator or any(r.name==role_name for r in getattr(interaction.user,"roles",[]))
        if not ok: await interaction.response.send_message("You are not authorized to control streams.",ephemeral=True)
        return ok

    @discord.ui.button(label="Go Live",style=discord.ButtonStyle.success,emoji="▶️",custom_id="stream_go_live",row=0)
    async def live(self,interaction:discord.Interaction,button:discord.ui.Button):
        if not await self.guard(interaction): return
        ok,msg=self.app.engine.start(str(interaction.user)); await interaction.response.send_message(msg,ephemeral=True)

    @discord.ui.button(label="Stop",style=discord.ButtonStyle.danger,emoji="⏹️",custom_id="stream_stop",row=0)
    async def stop(self,interaction:discord.Interaction,button:discord.ui.Button):
        if not await self.guard(interaction): return
        ok,msg=self.app.engine.stop(str(interaction.user)); await interaction.response.send_message(msg,ephemeral=True)

    @discord.ui.button(label="Restart",style=discord.ButtonStyle.secondary,emoji="🔄",custom_id="stream_restart",row=0)
    async def restart(self,interaction:discord.Interaction,button:discord.ui.Button):
        if not await self.guard(interaction): return
        ok,msg=self.app.engine.restart(str(interaction.user)); await interaction.response.send_message(msg,ephemeral=True)

    @discord.ui.button(label="Status",style=discord.ButtonStyle.primary,emoji="📊",custom_id="stream_status",row=1)
    async def status(self,interaction:discord.Interaction,button:discord.ui.Button):
        if not await self.guard(interaction): return
        s=self.app.engine.status(); m=self.app.mediamtx.status()
        txt=(f"**Stream:** {'🟢 LIVE' if s['running'] else '⚫ Stopped'}\n"
             f"**FFmpeg PID:** `{s['pid'] or '—'}`\n**RTMP ingest:** {'🟢' if m['running'] else '⚫'} MediaMTX\n"
             f"**OBS server:** `{self.app.cfg.get('obs_server')}`\n**OBS key:** `{self.app.cfg.get('obs_stream_key')}`\n"
             f"**Last FFmpeg message:** `{s['last_error'] or 'none'}`")
        await interaction.response.send_message(txt,ephemeral=True)

    @discord.ui.button(label="Schedule",style=discord.ButtonStyle.secondary,emoji="📅",custom_id="stream_schedule",row=1)
    async def schedule(self,interaction:discord.Interaction,button:discord.ui.Button):
        if not await self.guard(interaction): return
        await interaction.response.send_modal(ScheduleModal(self.app))

    @discord.ui.button(label="OBS Info",style=discord.ButtonStyle.secondary,emoji="🎥",custom_id="stream_obs",row=1)
    async def obs(self,interaction:discord.Interaction,button:discord.ui.Button):
        if not await self.guard(interaction): return
        await interaction.response.send_message(f"OBS **Server:** `{self.app.cfg.get('obs_server')}`\nOBS **Stream Key:** `{self.app.cfg.get('obs_stream_key')}`",ephemeral=True)

class DiscordController(commands.Bot):
    def __init__(self,app):
        intents=discord.Intents.default(); intents.message_content=True
        super().__init__(command_prefix="stream_",intents=intents); self.app=app

    async def setup_hook(self): self.add_view(StreamControlView(self.app))
    async def on_ready(self): print(f"Discord connected as {self.user}")

    def _authorized(self,member):
        role_name=self.app.cfg.get("discord_admin_role",os.getenv("DISCORD_ADMIN_ROLE","Stream Admin"))
        return member.guild_permissions.administrator or any(r.name==role_name for r in getattr(member,"roles",[]))

    @commands.command(name="panel")
    @commands.guild_only()
    async def panel(self,ctx):
        if not self._authorized(ctx.author): return await ctx.reply("Not authorized.")
        e=discord.Embed(title="📡 Multistream Control Center",description="YouTube • Twitch • Custom RTMP",color=0x6441A5)
        e.add_field(name="OBS Server",value=f"`{self.app.cfg.get('obs_server')}`",inline=False)
        e.add_field(name="OBS Stream Key",value=f"`{self.app.cfg.get('obs_stream_key')}`",inline=False)
        e.add_field(name="YouTube",value="✅ Enabled" if self.app.cfg.get("youtube_enabled") else "❌ Disabled")
        e.add_field(name="Twitch",value="✅ Enabled" if self.app.cfg.get("twitch_enabled") else "❌ Disabled")
        e.set_footer(text="v1.1.0 • Admin controls")
        await ctx.send(embed=e,view=StreamControlView(self.app))

    @commands.command(name="status")
    async def status_cmd(self,ctx):
        if not self._authorized(ctx.author): return
        s=self.app.engine.status(); await ctx.reply(f"Stream running: **{s['running']}** • PID `{s['pid'] or '—'}`")
