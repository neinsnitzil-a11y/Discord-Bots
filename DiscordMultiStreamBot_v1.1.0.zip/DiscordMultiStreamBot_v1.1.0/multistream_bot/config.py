from __future__ import annotations
import json
from pathlib import Path

DEFAULTS = {
    "app_version": "1.1.0",
    "source_url": "rtmp://127.0.0.1:1935/live/main",
    "obs_server": "rtmp://127.0.0.1:1935/live",
    "obs_stream_key": "main",
    "mediamtx_enabled": True,
    "mediamtx_auto_install": True,
    "youtube_enabled": False,
    "youtube_rtmp": "",
    "youtube_last_watch_url": "",
    "twitch_enabled": False,
    "twitch_rtmp": "rtmp://live.twitch.tv/app",
    "twitch_stream_key": "",
    "twitch_client_id": "",
    "twitch_client_secret": "",
    "twitch_redirect_uri": "http://127.0.0.1:17563/callback",
    "twitch_access_token": "",
    "twitch_refresh_token": "",
    "custom_outputs": [],
    "video_codec": "copy",
    "audio_codec": "copy",
    "video_bitrate": "6000k",
    "audio_bitrate": "160k",
    "preset": "veryfast",
    "reconnect": True,
    "auto_restart": True,
    "restart_delay_seconds": 5,
    "record_local": False,
    "record_path": "recordings/stream_%Y%m%d_%H%M%S.mkv",
    "announcement_channel_id": 0,
    "control_channel_id": 0,
    "discord_admin_role": "Stream Admin",
}

class ConfigStore:
    def __init__(self, data_dir: str):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.path = self.data_dir / "config.json"
        self.data = DEFAULTS.copy()
        self.load()

    def load(self):
        if self.path.exists():
            try:
                d = json.loads(self.path.read_text(encoding="utf-8"))
                if isinstance(d, dict):
                    self.data.update(d)
            except Exception:
                pass
        self.data["app_version"] = "1.1.0"
        self.save()

    def save(self):
        tmp = self.path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(self.data, indent=2), encoding="utf-8")
        tmp.replace(self.path)

    def get(self, key, default=None):
        return self.data.get(key, default)

    def set(self, key, value):
        self.data[key] = value
        self.save()

    def update(self, values: dict):
        self.data.update(values)
        self.save()
