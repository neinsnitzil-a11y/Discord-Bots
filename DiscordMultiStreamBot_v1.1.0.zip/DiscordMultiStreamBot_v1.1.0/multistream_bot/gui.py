from __future__ import annotations
import json, threading, tkinter as tk
from datetime import datetime, timezone
from tkinter import ttk, messagebox

class AppGUI:
    def __init__(self,app):
        self.app=app; self.root=tk.Tk(); self.root.title("Discord Multistream Bot v1.1.0"); self.root.geometry("980x760"); self.vars={}
        nb=ttk.Notebook(self.root); nb.pack(fill="both",expand=True,padx=10,pady=10)
        self.general=ttk.Frame(nb); self.platforms=ttk.Frame(nb); self.control=ttk.Frame(nb); self.youtube=ttk.Frame(nb); self.twitch=ttk.Frame(nb); self.schedule=ttk.Frame(nb)
        for w,t in [(self.general,"General / OBS"),(self.platforms,"Streaming"),(self.control,"Live Control"),(self.youtube,"YouTube"),(self.twitch,"Twitch"),(self.schedule,"Schedule")]: nb.add(w,text=t)
        self._general(); self._platforms(); self._control(); self._youtube(); self._twitch(); self._schedule(); self.refresh()

    def row(self,parent,label,key,show=None):
        f=ttk.Frame(parent); f.pack(fill="x",padx=12,pady=5); ttk.Label(f,text=label,width=24).pack(side="left")
        v=tk.StringVar(value=str(self.app.cfg.get(key,""))); self.vars[key]=v; ttk.Entry(f,textvariable=v,show=show).pack(side="left",fill="x",expand=True)

    def _general(self):
        ttk.Label(self.general,text="OBS sends one RTMP stream here. The bot forwards it to every enabled destination.",font=("Segoe UI",11,"bold")).pack(anchor="w",padx=12,pady=12)
        self.row(self.general,"OBS server","obs_server"); self.row(self.general,"OBS stream key","obs_stream_key"); self.row(self.general,"Internal source URL","source_url")
        self.mtx_status=tk.StringVar(value="MediaMTX: checking..."); ttk.Label(self.general,textvariable=self.mtx_status).pack(anchor="w",padx=12,pady=10)
        f=ttk.Frame(self.general); f.pack(anchor="w",padx=12,pady=6)
        ttk.Button(f,text="Install / Start RTMP Receiver",command=self.start_mtx).pack(side="left",padx=(0,8)); ttk.Button(f,text="Stop RTMP Receiver",command=self.stop_mtx).pack(side="left")
        ttk.Button(self.general,text="Save",command=self.save).pack(pady=12)

    def _platforms(self):
        self.yt=tk.BooleanVar(value=self.app.cfg.get("youtube_enabled")); self.tw=tk.BooleanVar(value=self.app.cfg.get("twitch_enabled")); self.rec=tk.BooleanVar(value=self.app.cfg.get("record_local")); self.ar=tk.BooleanVar(value=self.app.cfg.get("auto_restart",True))
        ttk.Checkbutton(self.platforms,text="Enable YouTube",variable=self.yt).pack(anchor="w",padx=12,pady=6); self.row(self.platforms,"YouTube RTMP URL","youtube_rtmp",show="*")
        ttk.Checkbutton(self.platforms,text="Enable Twitch",variable=self.tw).pack(anchor="w",padx=12,pady=6); self.row(self.platforms,"Twitch ingest","twitch_rtmp"); self.row(self.platforms,"Twitch stream key","twitch_stream_key",show="*")
        self.row(self.platforms,"Video codec","video_codec"); self.row(self.platforms,"Audio codec","audio_codec"); self.row(self.platforms,"Video bitrate","video_bitrate"); self.row(self.platforms,"Audio bitrate","audio_bitrate")
        ttk.Checkbutton(self.platforms,text="Record local copy",variable=self.rec).pack(anchor="w",padx=12,pady=5); ttk.Checkbutton(self.platforms,text="Auto-restart FFmpeg after a crash",variable=self.ar).pack(anchor="w",padx=12,pady=5)
        ttk.Button(self.platforms,text="Save",command=self.save).pack(pady=10)

    def _control(self):
        self.status=tk.StringVar(value="Stopped"); ttk.Label(self.control,textvariable=self.status,font=("Segoe UI",20,"bold")).pack(pady=25)
        for text,cmd in [("▶ GO LIVE",self.start),("⏹ STOP",self.stop),("🔄 RESTART",self.restart),("Refresh Status",self.refresh)]: ttk.Button(self.control,text=text,command=cmd).pack(ipadx=30,ipady=10,pady=6)
        self.last=tk.StringVar(value=""); ttk.Label(self.control,textvariable=self.last,wraplength=850).pack(padx=15,pady=10)

    def _youtube(self):
        self.yttitle=tk.StringVar(value="My Live Event"); self.ytstart=tk.StringVar(value=datetime.now(timezone.utc).replace(microsecond=0).isoformat()); self.ytprivacy=tk.StringVar(value="unlisted"); self.ytdesc=tk.StringVar(value="")
        for label,var in [("Title",self.yttitle),("Start (ISO 8601)",self.ytstart),("Privacy",self.ytprivacy),("Description",self.ytdesc)]:
            f=ttk.Frame(self.youtube); f.pack(fill="x",padx=12,pady=6); ttk.Label(f,text=label,width=22).pack(side="left"); ttk.Entry(f,textvariable=var).pack(side="left",fill="x",expand=True)
        ttk.Label(self.youtube,text="Place Google OAuth Desktop credentials at data/youtube_client_secret.json.").pack(anchor="w",padx=12,pady=10)
        ttk.Button(self.youtube,text="Connect / Authorize YouTube",command=self.ytauth).pack(pady=5); ttk.Button(self.youtube,text="Create Event + RTMP Stream",command=self.ytcreate).pack(pady=5)

    def _twitch(self):
        self.row(self.twitch,"Twitch Client ID","twitch_client_id"); self.row(self.twitch,"Twitch Client Secret","twitch_client_secret",show="*"); self.row(self.twitch,"OAuth redirect URI","twitch_redirect_uri")
        ttk.Label(self.twitch,text="Register the exact redirect URI above in your Twitch Developer application.").pack(anchor="w",padx=12,pady=10)
        ttk.Button(self.twitch,text="Save Twitch App Settings",command=self.save).pack(pady=5); ttk.Button(self.twitch,text="Connect Twitch + Get Stream Key",command=self.twauth).pack(pady=5)
        self.twstatus=tk.StringVar(value="Not checked"); ttk.Label(self.twitch,textvariable=self.twstatus).pack(pady=8)

    def _schedule(self):
        self.evtitle=tk.StringVar(value="Scheduled stream"); self.evtime=tk.StringVar(value=datetime.now().astimezone().replace(microsecond=0).isoformat()); self.evaction=tk.StringVar(value="start")
        for label,var in [("Event name",self.evtitle),("When (ISO 8601)",self.evtime),("Action start/stop",self.evaction)]:
            f=ttk.Frame(self.schedule); f.pack(fill="x",padx=12,pady=6); ttk.Label(f,text=label,width=22).pack(side="left"); ttk.Entry(f,textvariable=var).pack(side="left",fill="x",expand=True)
        ttk.Button(self.schedule,text="Add Scheduled Action",command=self.add_schedule).pack(pady=8); ttk.Button(self.schedule,text="Refresh Events",command=self.load_events).pack(pady=4)
        self.events=tk.Text(self.schedule,height=18); self.events.pack(fill="both",expand=True,padx=12,pady=10); self.load_events()

    def save(self):
        for k,v in self.vars.items(): self.app.cfg.set(k,v.get())
        self.app.cfg.update({"youtube_enabled":self.yt.get(),"twitch_enabled":self.tw.get(),"record_local":self.rec.get(),"auto_restart":self.ar.get()}); messagebox.showinfo("Saved","Configuration saved.")

    def start_mtx(self):
        def run():
            try: ok,msg=self.app.mediamtx.start(True); self.root.after(0,lambda:(messagebox.showinfo("RTMP Receiver",msg),self.refresh()))
            except Exception as e: self.root.after(0,lambda err=str(e):messagebox.showerror("RTMP Receiver",err))
        threading.Thread(target=run,daemon=True).start()
    def stop_mtx(self): messagebox.showinfo("RTMP Receiver",self.app.mediamtx.stop()[1]); self.refresh()
    def start(self): self.save(); ok,msg=self.app.engine.start("desktop_gui"); messagebox.showinfo("Stream",msg); self.refresh()
    def stop(self): ok,msg=self.app.engine.stop("desktop_gui"); messagebox.showinfo("Stream",msg); self.refresh()
    def restart(self): self.save(); ok,msg=self.app.engine.restart("desktop_gui"); messagebox.showinfo("Stream",msg); self.refresh()
    def refresh(self):
        s=self.app.engine.status(); m=self.app.mediamtx.status(); self.status.set(f"LIVE • PID {s['pid']}" if s['running'] else "Stopped"); self.last.set(s['last_error'] or "No FFmpeg errors reported"); self.mtx_status.set(f"MediaMTX: {'RUNNING' if m['running'] else 'stopped'} • {'installed' if m['installed'] else 'not installed'}")

    def ytauth(self):
        def run():
            try:self.app.youtube.authenticate(); self.root.after(0,lambda:messagebox.showinfo("YouTube","Authorization complete."))
            except Exception as e:self.root.after(0,lambda err=str(e):messagebox.showerror("YouTube",err))
        threading.Thread(target=run,daemon=True).start()
    def ytcreate(self):
        def run():
            try:
                r=self.app.youtube.create_event(self.yttitle.get(),self.ytstart.get(),self.ytprivacy.get(),self.ytdesc.get()); self.app.cfg.update({"youtube_rtmp":r["rtmp_url"],"youtube_enabled":True,"youtube_last_watch_url":r["watch_url"]})
                self.root.after(0,lambda:messagebox.showinfo("Created",f"Watch: {r['watch_url']}\nRTMP output saved."))
            except Exception as e:self.root.after(0,lambda err=str(e):messagebox.showerror("YouTube",err))
        threading.Thread(target=run,daemon=True).start()
    def twauth(self):
        self.save()
        def run():
            try:
                u=self.app.twitch.authenticate(); self.root.after(0,lambda:(self.twstatus.set(f"Connected as {u.get('display_name',u.get('login'))}"),messagebox.showinfo("Twitch","Connected and stream key stored.")))
            except Exception as e:self.root.after(0,lambda err=str(e):messagebox.showerror("Twitch",err))
        threading.Thread(target=run,daemon=True).start()
    def add_schedule(self):
        try:
            dt=datetime.fromisoformat(self.evtime.get().replace("Z","+00:00")); act=self.evaction.get().strip().lower()
            if act not in {"start","stop"}: raise ValueError("Action must be start or stop")
            eid=self.app.db.add_event(self.evtitle.get(),dt.isoformat(),act,"desktop_gui",datetime.now(timezone.utc).isoformat()); messagebox.showinfo("Scheduled",f"Event #{eid} added."); self.load_events()
        except Exception as e: messagebox.showerror("Schedule",str(e))
    def load_events(self):
        if not hasattr(self,"events"): return
        rows=self.app.db.pending_events(); self.events.delete("1.0","end"); self.events.insert("end","\n".join(f"#{r['id']}  {r['scheduled_at']}  {r['action'].upper()}  {r['title']}" for r in rows) or "No pending events.")
    def run(self): self.root.mainloop()
