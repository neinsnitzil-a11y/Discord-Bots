import json, sqlite3
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS stream_sessions(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 started_at TEXT NOT NULL,
 ended_at TEXT,
 status TEXT NOT NULL,
 source_url TEXT,
 outputs_json TEXT,
 pid INTEGER
);
CREATE TABLE IF NOT EXISTS audit_log(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 created_at TEXT NOT NULL,
 actor TEXT,
 action TEXT NOT NULL,
 details TEXT
);
CREATE TABLE IF NOT EXISTS scheduled_events(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 title TEXT NOT NULL,
 scheduled_at TEXT NOT NULL,
 action TEXT NOT NULL DEFAULT 'start',
 enabled INTEGER NOT NULL DEFAULT 1,
 created_by TEXT,
 created_at TEXT NOT NULL,
 fired_at TEXT
);
"""

class Database:
    def __init__(self, data_dir: str):
        p = Path(data_dir); p.mkdir(parents=True, exist_ok=True)
        self.path = p / "streambot.db"
        with self.connect() as c:
            c.executescript(SCHEMA)

    def connect(self):
        c = sqlite3.connect(self.path, timeout=20)
        c.row_factory = sqlite3.Row
        return c

    def log(self, created_at, actor, action, details=""):
        with self.connect() as c:
            c.execute("INSERT INTO audit_log(created_at,actor,action,details) VALUES(?,?,?,?)", (created_at, actor, action, details))

    def create_session(self, started_at, source_url, outputs, pid):
        with self.connect() as c:
            cur = c.execute("INSERT INTO stream_sessions(started_at,status,source_url,outputs_json,pid) VALUES(?,?,?,?,?)",
                            (started_at, "running", source_url, json.dumps(outputs), pid))
            return cur.lastrowid

    def end_session(self, session_id, ended_at, status="stopped"):
        if not session_id: return
        with self.connect() as c:
            c.execute("UPDATE stream_sessions SET ended_at=?,status=? WHERE id=?", (ended_at, status, session_id))

    def add_event(self, title, scheduled_at, action, created_by, created_at):
        with self.connect() as c:
            cur=c.execute("INSERT INTO scheduled_events(title,scheduled_at,action,created_by,created_at) VALUES(?,?,?,?,?)",
                          (title,scheduled_at,action,created_by,created_at))
            return cur.lastrowid

    def pending_events(self):
        with self.connect() as c:
            return [dict(r) for r in c.execute("SELECT * FROM scheduled_events WHERE enabled=1 AND fired_at IS NULL ORDER BY scheduled_at")]

    def mark_event_fired(self, event_id, fired_at):
        with self.connect() as c:
            c.execute("UPDATE scheduled_events SET fired_at=? WHERE id=?",(fired_at,event_id))

    def cancel_event(self,event_id):
        with self.connect() as c:
            c.execute("UPDATE scheduled_events SET enabled=0 WHERE id=?",(event_id,))
