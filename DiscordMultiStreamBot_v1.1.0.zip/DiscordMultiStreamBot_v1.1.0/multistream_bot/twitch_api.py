from __future__ import annotations
import json, secrets, threading, time, urllib.parse, webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
import requests

class TwitchManager:
    API="https://api.twitch.tv/helix"
    TOKEN_URL="https://id.twitch.tv/oauth2/token"
    AUTH_URL="https://id.twitch.tv/oauth2/authorize"
    SCOPES=["channel:read:stream_key","channel:manage:broadcast"]

    def __init__(self, cfg): self.cfg=cfg

    @property
    def client_id(self): return self.cfg.get("twitch_client_id","")
    @property
    def access_token(self): return self.cfg.get("twitch_access_token","")
    @property
    def headers(self): return {"Client-Id":self.client_id,"Authorization":f"Bearer {self.access_token}"}

    def authenticate(self):
        cid=self.client_id; secret=self.cfg.get("twitch_client_secret",""); redirect=self.cfg.get("twitch_redirect_uri")
        if not cid or not secret: raise RuntimeError("Set Twitch Client ID and Client Secret first")
        parsed=urllib.parse.urlparse(redirect)
        if parsed.hostname not in {"127.0.0.1","localhost"}: raise RuntimeError("This build expects a local Twitch OAuth redirect URI")
        state=secrets.token_urlsafe(24); result={}; done=threading.Event()
        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                q=urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
                if q.get("state",[""])[0] != state: result["error"]="OAuth state mismatch"
                elif "error" in q: result["error"]=q.get("error_description",q["error"])[0]
                else: result["code"]=q.get("code",[""])[0]
                self.send_response(200); self.send_header("Content-Type","text/html"); self.end_headers()
                self.wfile.write(b"<h2>Twitch authorization received.</h2><p>You can return to Discord Multistream Bot.</p>")
                done.set()
            def log_message(self,*args): pass
        port=parsed.port or 80
        server=HTTPServer((parsed.hostname,port),Handler)
        threading.Thread(target=server.handle_request,daemon=True).start()
        url=self.AUTH_URL+"?"+urllib.parse.urlencode({"client_id":cid,"redirect_uri":redirect,"response_type":"code","scope":" ".join(self.SCOPES),"state":state,"force_verify":"true"})
        webbrowser.open(url)
        if not done.wait(180): server.server_close(); raise TimeoutError("Timed out waiting for Twitch OAuth callback")
        server.server_close()
        if result.get("error"): raise RuntimeError(result["error"])
        r=requests.post(self.TOKEN_URL,data={"client_id":cid,"client_secret":secret,"code":result["code"],"grant_type":"authorization_code","redirect_uri":redirect},timeout=30)
        r.raise_for_status(); tok=r.json()
        self.cfg.update({"twitch_access_token":tok.get("access_token",""),"twitch_refresh_token":tok.get("refresh_token","")})
        user=self.get_user(); key=self.get_stream_key(user["id"])
        self.cfg.update({"twitch_stream_key":key or "","twitch_enabled":True})
        return user

    def refresh(self):
        ref=self.cfg.get("twitch_refresh_token","")
        if not ref: raise RuntimeError("No Twitch refresh token stored")
        r=requests.post(self.TOKEN_URL,data={"grant_type":"refresh_token","refresh_token":ref,"client_id":self.client_id,"client_secret":self.cfg.get("twitch_client_secret","")},timeout=30)
        r.raise_for_status(); tok=r.json(); self.cfg.update({"twitch_access_token":tok.get("access_token",""),"twitch_refresh_token":tok.get("refresh_token",ref)})
        return True

    def get_user(self):
        r=requests.get(self.API+"/users",headers=self.headers,timeout=20)
        if r.status_code==401 and self.cfg.get("twitch_refresh_token"):
            self.refresh(); r=requests.get(self.API+"/users",headers=self.headers,timeout=20)
        r.raise_for_status(); d=r.json().get("data",[]); return d[0] if d else None

    def get_stream_key(self, broadcaster_id):
        r=requests.get(self.API+"/streams/key",params={"broadcaster_id":broadcaster_id},headers=self.headers,timeout=20); r.raise_for_status()
        d=r.json().get("data",[]); return d[0].get("stream_key") if d else None

    def update_channel(self,broadcaster_id,title=None,game_id=None,tags=None):
        body={}
        if title: body["title"]=title
        if game_id: body["game_id"]=game_id
        if tags: body["tags"]=tags[:10]
        r=requests.patch(self.API+"/channels",params={"broadcaster_id":broadcaster_id},json=body,headers=self.headers,timeout=20); r.raise_for_status(); return True
