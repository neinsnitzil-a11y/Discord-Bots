from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone

SCOPES=["https://www.googleapis.com/auth/youtube"]

class YouTubeManager:
    def __init__(self, data_dir: str):
        self.data_dir=Path(data_dir); self.data_dir.mkdir(parents=True, exist_ok=True)
        self.client_secret=self.data_dir/"youtube_client_secret.json"
        self.token_file=self.data_dir/"youtube_token.json"

    def authenticate(self):
        from google.oauth2.credentials import Credentials
        from google_auth_oauthlib.flow import InstalledAppFlow
        creds=None
        if self.token_file.exists():
            creds=Credentials.from_authorized_user_file(str(self.token_file), SCOPES)
        if not creds or not creds.valid:
            if creds and creds.expired and creds.refresh_token:
                from google.auth.transport.requests import Request
                creds.refresh(Request())
            else:
                if not self.client_secret.exists():
                    raise FileNotFoundError(f"Place Google OAuth desktop credentials at {self.client_secret}")
                flow=InstalledAppFlow.from_client_secrets_file(str(self.client_secret), SCOPES)
                creds=flow.run_local_server(port=0, access_type="offline", prompt="consent")
            self.token_file.write_text(creds.to_json(), encoding="utf-8")
        return creds

    def service(self):
        from googleapiclient.discovery import build
        return build("youtube","v3",credentials=self.authenticate(),cache_discovery=False)

    def create_event(self, title: str, start_time_iso: str, privacy="unlisted", description="", resolution="1080p", fps="60fps"):
        yt=self.service()
        b=yt.liveBroadcasts().insert(part="snippet,status,contentDetails", body={
            "snippet":{"title":title,"description":description,"scheduledStartTime":start_time_iso},
            "status":{"privacyStatus":privacy},
            "contentDetails":{"enableAutoStart":True,"enableAutoStop":True}
        }).execute()
        s=yt.liveStreams().insert(part="snippet,cdn,contentDetails,status", body={
            "snippet":{"title":f"{title} ingest"},
            "cdn":{"frameRate":fps,"ingestionType":"rtmp","resolution":resolution},
            "contentDetails":{"isReusable":False}
        }).execute()
        yt.liveBroadcasts().bind(part="id,snippet,status", id=b["id"], streamId=s["id"]).execute()
        ingestion=s.get("cdn",{}).get("ingestionInfo",{})
        addr=ingestion.get("ingestionAddress",""); name=ingestion.get("streamName","")
        return {"broadcast_id":b["id"],"stream_id":s["id"],"watch_url":f"https://www.youtube.com/watch?v={b['id']}","rtmp_url":f"{addr}/{name}" if addr and name else ""}
