from __future__ import annotations
import subprocess, threading, time
from datetime import datetime, timezone
from pathlib import Path

class StreamEngine:
    def __init__(self, cfg, db, ffmpeg_path="ffmpeg"):
        self.cfg,self.db,self.ffmpeg_path=cfg,db,ffmpeg_path
        self.proc=None; self._lock=threading.RLock(); self.last_error=""; self._wanted=False; self.session_id=None
        self._watchdog=threading.Thread(target=self._watchdog_loop,daemon=True,name="ffmpeg-watchdog"); self._watchdog.start()

    @property
    def running(self): return self.proc is not None and self.proc.poll() is None

    def _outputs(self):
        out=[]
        if self.cfg.get("youtube_enabled") and self.cfg.get("youtube_rtmp"): out.append(("YouTube",self.cfg.get("youtube_rtmp")))
        if self.cfg.get("twitch_enabled") and self.cfg.get("twitch_stream_key"):
            base=self.cfg.get("twitch_rtmp","rtmp://live.twitch.tv/app").rstrip("/"); out.append(("Twitch",f"{base}/{self.cfg.get('twitch_stream_key')}") )
        for i,u in enumerate(self.cfg.get("custom_outputs",[]),1):
            if u: out.append((f"Custom {i}",u))
        return out

    def build_command(self):
        src=self.cfg.get("source_url"); outputs=self._outputs()
        if not src: raise RuntimeError("No source URL configured")
        if not outputs: raise RuntimeError("No enabled streaming destination configured")
        cmd=[self.ffmpeg_path,"-hide_banner","-loglevel","warning","-i",src]
        v=self.cfg.get("video_codec","copy"); a=self.cfg.get("audio_codec","copy")
        cmd += ["-c:v",v,"-c:a",a]
        if v != "copy": cmd += ["-preset",self.cfg.get("preset","veryfast"),"-b:v",self.cfg.get("video_bitrate","6000k")]
        if a != "copy": cmd += ["-b:a",self.cfg.get("audio_bitrate","160k")]
        # tee muxer gives each output a dedicated slave and avoids multiple output-map ambiguity.
        tee=[]
        for _,url in outputs: tee.append(f"[f=flv:onfail=ignore]{url}")
        if self.cfg.get("record_local"):
            rel=datetime.now().strftime(self.cfg.get("record_path","recordings/stream_%Y%m%d_%H%M%S.mkv")); path=Path(self.cfg.data_dir)/rel; path.parent.mkdir(parents=True,exist_ok=True)
            tee.append(f"[f=matroska:onfail=ignore]{path}")
        cmd += ["-map","0:v?","-map","0:a?","-f","tee","|".join(tee)]
        return cmd,outputs

    def _spawn(self,actor):
        cmd,outs=self.build_command(); self.last_error=""
        try:self.proc=subprocess.Popen(cmd,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,text=True,encoding="utf-8",errors="replace")
        except FileNotFoundError:return False,f"FFmpeg not found at: {self.ffmpeg_path}"
        now=datetime.now(timezone.utc).isoformat(); self.session_id=self.db.create_session(now,self.cfg.get("source_url"),[n for n,_ in outs],self.proc.pid)
        self.db.log(now,actor,"stream_start",", ".join(n for n,_ in outs)); threading.Thread(target=self._watch_stderr,args=(self.proc,),daemon=True).start()
        return True,f"Started PID {self.proc.pid}: "+", ".join(n for n,_ in outs)

    def start(self,actor="system"):
        with self._lock:
            if self.running:return False,"Stream is already running"
            self._wanted=True
            return self._spawn(actor)

    def _watch_stderr(self,proc):
        if not proc.stderr:return
        for line in proc.stderr:
            if line.strip(): self.last_error=line.strip()[-800:]

    def _watchdog_loop(self):
        while True:
            time.sleep(2)
            with self._lock:
                if self._wanted and self.proc and self.proc.poll() is not None:
                    code=self.proc.returncode; now=datetime.now(timezone.utc).isoformat(); self.db.end_session(self.session_id,now,"crashed"); self.session_id=None
                    self.db.log(now,"watchdog","ffmpeg_exit",f"returncode={code}; {self.last_error}")
                    if self.cfg.get("auto_restart",True):
                        delay=max(1,int(self.cfg.get("restart_delay_seconds",5))); time.sleep(delay)
                        try:self._spawn("watchdog")
                        except Exception as e:self.last_error=str(e)
                    else:self._wanted=False

    def stop(self,actor="system"):
        with self._lock:
            self._wanted=False
            if not self.running:return False,"No active stream"
            p=self.proc; p.terminate()
            try:p.wait(timeout=8)
            except subprocess.TimeoutExpired:p.kill(); p.wait(timeout=3)
            now=datetime.now(timezone.utc).isoformat(); self.db.end_session(self.session_id,now,"stopped"); self.session_id=None; self.db.log(now,actor,"stream_stop",f"pid={p.pid}")
            return True,"Stream stopped"

    def restart(self,actor="system"):
        self.stop(actor); time.sleep(1); return self.start(actor)

    def status(self):
        return {"running":self.running,"wanted":self._wanted,"pid":self.proc.pid if self.running else None,"last_error":self.last_error}
