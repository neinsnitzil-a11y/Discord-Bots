from __future__ import annotations
import io, json, os, platform, shutil, subprocess, tarfile, urllib.request, zipfile
from pathlib import Path

class MediaMTXManager:
    """Downloads and runs MediaMTX locally so OBS has an RTMP ingest endpoint."""
    def __init__(self, data_dir: str):
        self.root = Path(data_dir) / "runtime" / "mediamtx"
        self.root.mkdir(parents=True, exist_ok=True)
        self.proc = None

    @property
    def exe(self):
        return self.root / ("mediamtx.exe" if os.name == "nt" else "mediamtx")

    @property
    def installed(self):
        return self.exe.exists()

    def _asset_fragment(self):
        sys=platform.system().lower(); machine=platform.machine().lower()
        arch = "amd64" if machine in {"x86_64","amd64"} else "arm64" if "arm" in machine or "aarch64" in machine else "amd64"
        if "windows" in sys: return f"windows_{arch}.zip"
        if "darwin" in sys: return f"darwin_{arch}.tar.gz"
        return f"linux_{arch}.tar.gz"

    def install_latest(self):
        req=urllib.request.Request("https://api.github.com/repos/bluenviron/mediamtx/releases/latest", headers={"User-Agent":"DiscordMultiStreamBot/1.1"})
        with urllib.request.urlopen(req, timeout=30) as r:
            release=json.load(r)
        frag=self._asset_fragment()
        asset=next((a for a in release.get("assets",[]) if a.get("name","").endswith(frag)),None)
        if not asset: raise RuntimeError(f"No MediaMTX release asset found for {frag}")
        with urllib.request.urlopen(asset["browser_download_url"], timeout=120) as r:
            raw=r.read()
        if frag.endswith(".zip"):
            with zipfile.ZipFile(io.BytesIO(raw)) as z: z.extractall(self.root)
        else:
            with tarfile.open(fileobj=io.BytesIO(raw), mode="r:gz") as t: t.extractall(self.root)
        if not self.exe.exists(): raise RuntimeError("MediaMTX installed archive did not contain expected executable")
        if os.name != "nt": self.exe.chmod(0o755)
        return str(self.exe)

    def write_config(self):
        path=self.root/"mediamtx.yml"
        path.write_text("""logLevel: info\nrtmp: yes\nrtmpAddress: :1935\nhls: no\nwebrtc: no\nsrt: no\npaths:\n  all_others:\n""",encoding="utf-8")
        return path

    def start(self, auto_install=True):
        if self.proc and self.proc.poll() is None: return True, "MediaMTX already running"
        if not self.installed:
            if not auto_install: return False, "MediaMTX is not installed"
            self.install_latest()
        cfg=self.write_config()
        self.proc=subprocess.Popen([str(self.exe), str(cfg)], cwd=self.root, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True, f"MediaMTX started (PID {self.proc.pid})"

    def stop(self):
        if not self.proc or self.proc.poll() is not None: return False, "MediaMTX is not running"
        self.proc.terminate()
        try:self.proc.wait(timeout=5)
        except subprocess.TimeoutExpired:self.proc.kill()
        return True,"MediaMTX stopped"

    def status(self):
        return {"installed":self.installed,"running":bool(self.proc and self.proc.poll() is None),"pid":self.proc.pid if self.proc and self.proc.poll() is None else None}
