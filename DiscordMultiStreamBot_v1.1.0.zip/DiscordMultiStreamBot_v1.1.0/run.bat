@echo off
setlocal
cd /d "%~dp0"
if not exist .venv (
  echo Virtual environment missing. Running installer first...
  call install.bat
)
call .venv\Scripts\activate.bat
if not exist .env copy .env.example .env
python main.py
pause
