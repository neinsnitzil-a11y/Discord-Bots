# Discord Multistream Bot v1.1.0

A self-hosted Discord + desktop controlled multistream system for sending one OBS feed to YouTube, Twitch, and optional custom RTMP destinations.

## What v1.1.0 adds

- Built-in **MediaMTX management** so the application supplies the local RTMP ingest used by OBS.
- Automatic MediaMTX download on first launch from its official GitHub release.
- OBS connection values shown in both the desktop GUI and Discord control panel.
- Browser-based **Twitch OAuth** flow.
- Twitch stream-key retrieval after authorization.
- Twitch access-token refresh support.
- YouTube OAuth and automatic live broadcast + RTMP stream creation.
- Persistent scheduled stream **start/stop events** stored in SQLite.
- FFmpeg watchdog with automatic restart after unexpected exits.
- Stream session history and audit logging.
- Start, stop, restart, status, OBS-info, and scheduling buttons in Discord.
- Local recording option.
- YouTube, Twitch, and custom RTMP fan-out.
- Persistent `data/` folder so normal code upgrades do not reset setup, OAuth tokens, database, schedules, or recordings.

## Architecture

```text
OBS / Streamlabs
       |
       | one RTMP feed
       v
MediaMTX on this computer
rtmp://127.0.0.1:1935/live/main
       |
       v
     FFmpeg
   /    |     \
YouTube Twitch Custom RTMP
```

## Windows setup

1. Extract the ZIP to a permanent folder.
2. Run `install.bat`.
3. Edit `.env` and set your Discord bot token.
4. Run `run.bat`.
5. The application attempts to start MediaMTX automatically.
6. Open OBS -> **Settings -> Stream -> Service: Custom**.
7. Enter:
   - Server: `rtmp://127.0.0.1:1935/live`
   - Stream Key: `main`
8. Connect YouTube and/or Twitch in the desktop GUI.
9. Start streaming from OBS.
10. Press **GO LIVE** in the desktop GUI or use the Discord control panel.

## Discord setup

Create a Discord bot in the Discord Developer Portal and enable Message Content Intent if you want to use the text commands.

Set in `.env`:

```env
DISCORD_TOKEN=YOUR_BOT_TOKEN
DISCORD_ADMIN_ROLE=Stream Admin
DATA_DIR=./data
FFMPEG_PATH=ffmpeg
```

Invite the bot with permissions to read/send messages and embed links.

The default control command is:

```text
stream_panel
```

That posts a persistent button panel with:

- Go Live
- Stop
- Restart
- Status
- Schedule
- OBS Info

Administrators and members with the configured `Stream Admin` role can use the controls.

## YouTube configuration

1. Create a Google Cloud project.
2. Enable **YouTube Data API v3**.
3. Configure an OAuth consent screen.
4. Create an OAuth **Desktop application** credential.
5. Download the JSON credentials.
6. Rename/copy the file to:

```text
data/youtube_client_secret.json
```

7. Open the YouTube tab and click **Connect / Authorize YouTube**.
8. Create a live event from the GUI. The application creates the YouTube broadcast, creates an RTMP stream, binds them, and saves the returned RTMP destination.

OAuth tokens are stored under `data/` so they survive application upgrades.

## Twitch configuration

1. Create an application in the Twitch Developer Console.
2. Add this OAuth redirect URL exactly:

```text
http://127.0.0.1:17563/callback
```

3. Copy the Twitch Client ID and Client Secret into the Twitch tab.
4. Click **Save Twitch App Settings**.
5. Click **Connect Twitch + Get Stream Key**.
6. Complete the Twitch authorization in the browser.

The application requests the scopes needed to read the broadcaster stream key and manage broadcast metadata. It then stores the access/refresh tokens and retrieves the stream key for FFmpeg use.

## Scheduling

The Schedule tab and Discord **Schedule** button accept ISO-8601 timestamps.

Examples:

```text
2026-10-03T20:00:00-04:00
2026-10-04T00:00:00Z
```

Actions can be:

```text
start
stop
```

Schedules are saved to `data/streambot.db` and survive restarts.

## Crash recovery

When **Auto-restart FFmpeg after a crash** is enabled, the watchdog detects an unexpected FFmpeg exit, records it in SQLite, waits for the configured restart delay, and launches FFmpeg again.

Manual Stop disables the watchdog restart so the stream stays stopped intentionally.

## Persistent data

Do not delete the `data/` directory during upgrades.

It stores items such as:

```text
data/
  config.json
  streambot.db
  youtube_client_secret.json
  youtube_token.json
  runtime/mediamtx/
  recordings/
```

The `.env` file and `.venv` folder should also normally be preserved when replacing application code.

## Codec recommendations

If OBS already sends H.264 video + AAC audio compatible with Twitch and YouTube, use:

```text
Video codec: copy
Audio codec: copy
```

This minimizes CPU/GPU use.

To transcode instead, a common software configuration is:

```text
Video codec: libx264
Audio codec: aac
Video bitrate: 6000k
Audio bitrate: 160k
```

## Important notes

- FFmpeg performs the actual stream fan-out. Platform APIs do not transmit the media themselves.
- Never post OAuth client secrets, access tokens, refresh tokens, or stream keys in public Discord channels.
- The Discord status/OBS controls use ephemeral replies where secrets could otherwise be exposed.
- For a production public server, restrict filesystem access to the bot host and back up the `data/` directory.
- MediaMTX is a separate third-party project downloaded from its official GitHub release at runtime; it is not redistributed inside this source archive.

## Project layout

```text
main.py
multistream_bot/
  config.py
  database.py
  discord_bot.py
  gui.py
  mediamtx.py
  scheduler.py
  stream_engine.py
  twitch_api.py
  youtube_api.py
install.bat
run.bat
requirements.txt
.env.example
README.md
```
