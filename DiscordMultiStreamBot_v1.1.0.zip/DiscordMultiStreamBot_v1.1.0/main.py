import os, threading
from dotenv import load_dotenv
load_dotenv()
from multistream_bot.config import ConfigStore
from multistream_bot.database import Database
from multistream_bot.stream_engine import StreamEngine
from multistream_bot.youtube_api import YouTubeManager
from multistream_bot.twitch_api import TwitchManager
from multistream_bot.mediamtx import MediaMTXManager
from multistream_bot.scheduler import EventScheduler
from multistream_bot.discord_bot import DiscordController
from multistream_bot.gui import AppGUI

class Application:
    def __init__(self):
        data_dir=os.getenv("DATA_DIR","./data")
        self.cfg=ConfigStore(data_dir); self.db=Database(data_dir); self.mediamtx=MediaMTXManager(data_dir)
        self.engine=StreamEngine(self.cfg,self.db,os.getenv("FFMPEG_PATH","ffmpeg")); self.youtube=YouTubeManager(data_dir); self.twitch=TwitchManager(self.cfg); self.bot=None
        self.scheduler=EventScheduler(self); self.scheduler.start()
        if self.cfg.get("mediamtx_enabled",True): threading.Thread(target=self._start_ingest,daemon=True).start()
    def _start_ingest(self):
        try:self.mediamtx.start(self.cfg.get("mediamtx_auto_install",True))
        except Exception as e: print("MediaMTX startup:",e)
    def start_discord(self):
        token=os.getenv("DISCORD_TOKEN","").strip()
        if not token: print("DISCORD_TOKEN not set; Discord controller disabled."); return
        self.bot=DiscordController(self); self.bot.run(token,log_handler=None)

if __name__=="__main__":
    app=Application(); threading.Thread(target=app.start_discord,daemon=True).start(); AppGUI(app).run()
