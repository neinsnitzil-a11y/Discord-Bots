
import re
import time
from collections import defaultdict, deque
from datetime import datetime, timezone, timedelta
import discord

INVITE_RE = re.compile(r"(?:discord\.gg/|discord(?:app)?\.com/invite/)[A-Za-z0-9-]+", re.I)
URL_RE = re.compile(r"https?://[^\s<>()]+", re.I)

class AutoModEngine:
    def __init__(self, bot):
        self.bot = bot
        self.user_windows = defaultdict(deque)
        self.duplicates = defaultdict(deque)
        self.join_windows = defaultdict(deque)

    def normalize(self, text):
        return re.sub(r"\s+"," ", (text or "").lower()).strip()

    async def scan_message(self, message: discord.Message):
        cfg = self.bot.config["automod"]
        if not cfg.get("enabled", True):
            return 0, []

        text = message.content or ""
        norm = self.normalize(text)
        score, reasons = 0, []

        for phrase in cfg.get("scam_phrases",[]):
            if phrase.lower() in norm:
                score += 5
                reasons.append(f"scam phrase: {phrase}")

        bad_cfg = cfg["bad_words"]
        if bad_cfg.get("enabled"):
            for word in bad_cfg.get("words",[]):
                if re.search(rf"\b{re.escape(word.lower())}\b", norm):
                    score += 4
                    reasons.append(f"blocked word: {word}")

        cap_cfg = cfg["caps"]
        if cap_cfg.get("enabled") and len(text) >= int(cap_cfg["min_length"]):
            letters = [c for c in text if c.isalpha()]
            if letters:
                ratio = sum(c.isupper() for c in letters) / len(letters)
                if ratio >= float(cap_cfg["ratio"]):
                    score += 2
                    reasons.append(f"excessive caps: {ratio:.0%}")

        mention_cfg = cfg["mentions"]
        mention_count = len(message.mentions) + len(message.role_mentions)
        if mention_cfg.get("enabled") and mention_count >= int(mention_cfg["max_mentions"]):
            score += 5
            reasons.append(f"mass mentions: {mention_count}")

        if cfg["invites"].get("enabled") and INVITE_RE.search(text):
            score += 5
            reasons.append("Discord invite")

        link_cfg = cfg["links"]
        if link_cfg.get("enabled"):
            from urllib.parse import urlparse
            for u in URL_RE.findall(text):
                host = (urlparse(u).hostname or "").lower()
                if host.startswith("www."):
                    host = host[4:]
                allowed = any(host == d or host.endswith("."+d) for d in link_cfg["allow_domains"])
                if not allowed:
                    score += 3
                    reasons.append(f"unapproved link: {host}")

        spam_cfg = cfg["spam"]
        if spam_cfg.get("enabled"):
            now = time.monotonic()
            key = (message.guild.id, message.author.id)
            q = self.user_windows[key]
            q.append(now)
            win = int(spam_cfg["window_seconds"])
            while q and now-q[0] > win:
                q.popleft()
            if len(q) >= int(spam_cfg["max_messages"]):
                score += 5
                reasons.append(f"message spam: {len(q)} in {win}s")

        dup_cfg = cfg["duplicate"]
        if dup_cfg.get("enabled") and norm:
            now = time.monotonic()
            key = (message.guild.id, message.author.id, norm[:500])
            q = self.duplicates[key]
            q.append(now)
            win = int(dup_cfg["window_seconds"])
            while q and now-q[0] > win:
                q.popleft()
            if len(q) >= int(dup_cfg["max_duplicates"]):
                score += 5
                reasons.append(f"duplicate spam: {len(q)} copies")

        age_days = (datetime.now(timezone.utc) - message.author.created_at).days
        if age_days < int(cfg.get("new_account_days",0)):
            score += int(cfg.get("new_account_extra_score",0))
            reasons.append(f"new account: {age_days}d")

        return score, reasons

    async def enforce(self, message, score, reasons):
        cfg = self.bot.config["automod"]
        if score < int(cfg["threshold_delete"]):
            return False

        action = "deleted"
        if cfg.get("delete_messages", True):
            try:
                await message.delete()
            except Exception:
                pass

        if score >= int(cfg["threshold_timeout"]):
            try:
                mins = int(cfg["timeout_minutes"])
                await message.author.timeout(
                    discord.utils.utcnow() + timedelta(minutes=mins),
                    reason="DISMAN AutoMod: " + "; ".join(reasons)[:300]
                )
                action = f"deleted + timeout {mins}m"
            except Exception:
                action = "deleted (timeout failed)"

        await self.bot.db.add_incident(
            message.guild.id, message.author.id, message.channel.id,
            "; ".join(dict.fromkeys(reasons)), action, message.content or ""
        )

        await self.bot.log_event(
            message.guild,
            "🛡️ AutoMod Action",
            f"**User:** {message.author.mention}\n**Channel:** {message.channel.mention}\n"
            f"**Action:** {action}\n**Score:** {score}\n"
            f"**Reasons:** " + ", ".join(dict.fromkeys(reasons))[:1000]
        )

        if cfg.get("dm_offender", True):
            try:
                await message.author.send(
                    f"Your message in **{message.guild.name}** triggered DISMAN AutoMod.\n"
                    f"Action: **{action}**\nReason: " + ", ".join(dict.fromkeys(reasons))[:800]
                )
            except Exception:
                pass
        return True

    async def member_joined(self, member: discord.Member):
        cfg = self.bot.config["raid"]
        if not cfg.get("enabled",True):
            return
        now = time.monotonic()
        q = self.join_windows[member.guild.id]
        q.append(now)
        win = int(cfg["join_window_seconds"])
        while q and now-q[0] > win:
            q.popleft()

        if len(q) >= int(cfg["join_threshold"]):
            await self.bot.log_event(
                member.guild,
                "🚨 Raid Threshold Triggered",
                f"{len(q)} joins occurred in {win} seconds."
            )
            if cfg.get("lockdown_on_trigger", True):
                await self.bot.lockdown_guild(member.guild)
