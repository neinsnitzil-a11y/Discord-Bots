
import json
import discord

TEMPLATES = {
    "music": {
        "name": "Music Production",
        "roles": [
            ("🎚 Producer", None), ("🎤 Artist", None), ("🎧 Engineer", None),
            ("🎹 Beatmaker", None), ("💎 VIP", None), ("🧯 Moderator", None)
        ],
        "categories": [
            ("📌 START HERE", [
                ("rules","text"), ("announcements","text"), ("roles","text"), ("introductions","text")
            ]),
            ("🎛 PRODUCTION", [
                ("general-production","text"), ("beats","text"), ("mixing-mastering","text"),
                ("plugins","text"), ("drumkits","text"), ("presets-banks","text"),
                ("midi","text"), ("loops-one-shots","text")
            ]),
            ("🤝 COMMUNITY", [
                ("general","text"), ("collabs","text"), ("self-promo","text"), ("feedback","text")
            ]),
            ("🔊 VOICE", [
                ("The Lounge","voice"), ("Studio Session 1","voice"), ("Studio Session 2","voice")
            ]),
            ("🛡 STAFF", [
                ("staff-chat","text"), ("mod-logs","text"), ("reports","text")
            ])
        ]
    },
    "community": {
        "name": "Community",
        "roles": [("Member",None),("VIP",None),("Moderator",None)],
        "categories": [
            ("START HERE",[("rules","text"),("announcements","text"),("introductions","text")]),
            ("COMMUNITY",[("general","text"),("media","text"),("memes","text"),("bot-commands","text")]),
            ("VOICE",[("General Voice","voice"),("Chill Voice","voice")]),
            ("STAFF",[("staff-chat","text"),("mod-logs","text")])
        ]
    },
    "gaming": {
        "name": "Gaming",
        "roles": [("Gamer",None),("Squad Lead",None),("VIP",None),("Moderator",None)],
        "categories": [
            ("START HERE",[("rules","text"),("announcements","text"),("roles","text")]),
            ("GAMING",[("general","text"),("looking-for-group","text"),("clips","text"),("screenshots","text")]),
            ("VOICE",[("Lobby","voice"),("Squad 1","voice"),("Squad 2","voice")]),
            ("STAFF",[("staff-chat","text"),("mod-logs","text")])
        ]
    },
    "minimal": {
        "name": "Minimal",
        "roles": [("Member",None),("Moderator",None)],
        "categories": [
            ("INFO",[("rules","text"),("announcements","text")]),
            ("CHAT",[("general","text")]),
            ("VOICE",[("General","voice")])
        ]
    }
}

async def create_template(guild: discord.Guild, key: str):
    tpl = TEMPLATES[key]
    created = {"roles":0,"categories":0,"channels":0}

    existing_roles = {r.name for r in guild.roles}
    for name, _ in tpl["roles"]:
        if name not in existing_roles:
            try:
                await guild.create_role(name=name, reason=f"DISMAN template: {tpl['name']}")
                created["roles"] += 1
            except discord.Forbidden:
                pass

    existing_categories = {c.name: c for c in guild.categories}
    for cat_name, channels in tpl["categories"]:
        category = existing_categories.get(cat_name)
        if not category:
            try:
                category = await guild.create_category(cat_name, reason=f"DISMAN template: {tpl['name']}")
                created["categories"] += 1
            except discord.Forbidden:
                continue

        existing = {c.name for c in category.channels}
        for ch_name, ch_type in channels:
            if ch_name in existing:
                continue
            try:
                if ch_type == "voice":
                    await guild.create_voice_channel(ch_name, category=category, reason="DISMAN template")
                else:
                    await guild.create_text_channel(ch_name, category=category, reason="DISMAN template")
                created["channels"] += 1
            except discord.Forbidden:
                pass

    return created

async def snapshot_guild(guild: discord.Guild):
    data = {
        "name": guild.name,
        "roles": [
            {"name":r.name,"permissions":r.permissions.value,"hoist":r.hoist,"mentionable":r.mentionable}
            for r in guild.roles if not r.is_default() and not r.managed
        ],
        "categories": []
    }
    for category in guild.categories:
        item = {"name":category.name,"channels":[]}
        for ch in category.channels:
            if isinstance(ch, discord.TextChannel):
                item["channels"].append({"name":ch.name,"type":"text","topic":ch.topic,"slowmode":ch.slowmode_delay})
            elif isinstance(ch, discord.VoiceChannel):
                item["channels"].append({"name":ch.name,"type":"voice","user_limit":ch.user_limit,"bitrate":ch.bitrate})
        data["categories"].append(item)
    return json.dumps(data)

async def additive_restore(guild: discord.Guild, snapshot_json: str):
    data = json.loads(snapshot_json)
    created = {"roles":0,"categories":0,"channels":0}

    existing_roles = {r.name for r in guild.roles}
    for r in data.get("roles",[]):
        if r["name"] not in existing_roles:
            try:
                perms = discord.Permissions(r.get("permissions",0))
                await guild.create_role(
                    name=r["name"], permissions=perms,
                    hoist=r.get("hoist",False), mentionable=r.get("mentionable",False),
                    reason="DISMAN additive restore"
                )
                created["roles"] += 1
            except discord.Forbidden:
                pass

    existing_categories = {c.name:c for c in guild.categories}
    for c in data.get("categories",[]):
        cat = existing_categories.get(c["name"])
        if not cat:
            try:
                cat = await guild.create_category(c["name"], reason="DISMAN additive restore")
                created["categories"] += 1
            except discord.Forbidden:
                continue
        names = {x.name for x in cat.channels}
        for ch in c.get("channels",[]):
            if ch["name"] in names:
                continue
            try:
                if ch["type"] == "voice":
                    await guild.create_voice_channel(
                        ch["name"], category=cat, user_limit=ch.get("user_limit",0),
                        reason="DISMAN additive restore"
                    )
                else:
                    await guild.create_text_channel(
                        ch["name"], category=cat, topic=ch.get("topic"),
                        slowmode_delay=ch.get("slowmode",0), reason="DISMAN additive restore"
                    )
                created["channels"] += 1
            except discord.Forbidden:
                pass
    return created
