
import discord
from services.builder import TEMPLATES, create_template, snapshot_guild, additive_restore
from .modals import CreateChannelModal, CreateRoleModal, SlowmodeModal, PurgeModal, WarnModal, TimeoutModal

def mod_ok(user: discord.Member):
    return user.guild_permissions.manage_guild or user.guild_permissions.administrator

class TemplateSelect(discord.ui.Select):
    def __init__(self, bot):
        options = [
            discord.SelectOption(label=v["name"], value=k, description=f"Build the {v['name']} template")
            for k,v in TEMPLATES.items()
        ]
        super().__init__(placeholder="Choose a server template…", min_values=1, max_values=1, options=options)
        self.bot = bot

    async def callback(self, interaction: discord.Interaction):
        if not mod_ok(interaction.user):
            await interaction.response.send_message("Manage Server permission required.", ephemeral=True)
            return
        await interaction.response.defer(ephemeral=True)
        result = await create_template(interaction.guild, self.values[0])
        await interaction.followup.send(
            f"✅ Template applied.\nRoles: **{result['roles']}** | Categories: **{result['categories']}** | Channels: **{result['channels']}**",
            ephemeral=True
        )

class MainDashboard(discord.ui.View):
    def __init__(self, bot):
        super().__init__(timeout=None)
        self.bot = bot
        self.add_item(TemplateSelect(bot))

    async def interaction_check(self, interaction):
        if mod_ok(interaction.user):
            return True
        await interaction.response.send_message("DISMAN's management panel is staff-only.", ephemeral=True)
        return False

    @discord.ui.button(label="Create Channel", style=discord.ButtonStyle.primary, emoji="➕", custom_id="disman:create_channel")
    async def create_channel(self, interaction, button):
        await interaction.response.send_modal(CreateChannelModal(self.bot))

    @discord.ui.button(label="Create Role", style=discord.ButtonStyle.primary, emoji="🏷️", custom_id="disman:create_role")
    async def create_role(self, interaction, button):
        await interaction.response.send_modal(CreateRoleModal())

    @discord.ui.button(label="Snapshot", style=discord.ButtonStyle.secondary, emoji="💾", custom_id="disman:snapshot")
    async def snapshot(self, interaction, button):
        await interaction.response.defer(ephemeral=True)
        data = await snapshot_guild(interaction.guild)
        sid = await self.bot.db.add_snapshot(interaction.guild.id, f"Snapshot by {interaction.user}", data)
        await interaction.followup.send(f"✅ Saved server structure snapshot **#{sid}**.", ephemeral=True)

    @discord.ui.button(label="Restore Latest", style=discord.ButtonStyle.secondary, emoji="♻️", custom_id="disman:restore")
    async def restore(self, interaction, button):
        await interaction.response.defer(ephemeral=True)
        snap = await self.bot.db.latest_snapshot(interaction.guild.id)
        if not snap:
            await interaction.followup.send("No snapshot exists yet.", ephemeral=True)
            return
        result = await additive_restore(interaction.guild, snap[2])
        await interaction.followup.send(
            f"✅ Additive restore completed from snapshot **#{snap[0]}**.\n"
            f"Created: {result['roles']} roles, {result['categories']} categories, {result['channels']} channels.\n"
            "Existing channels/roles were not deleted.",
            ephemeral=True
        )

    @discord.ui.button(label="Lockdown", style=discord.ButtonStyle.danger, emoji="🔒", custom_id="disman:lockdown")
    async def lockdown(self, interaction, button):
        await interaction.response.defer(ephemeral=True)
        count = await self.bot.lockdown_guild(interaction.guild)
        await interaction.followup.send(f"🔒 Locked sending in **{count}** text channels.", ephemeral=True)

    @discord.ui.button(label="Unlock", style=discord.ButtonStyle.success, emoji="🔓", custom_id="disman:unlock")
    async def unlock(self, interaction, button):
        await interaction.response.defer(ephemeral=True)
        count = await self.bot.unlock_guild(interaction.guild)
        await interaction.followup.send(f"🔓 Restored sending in **{count}** text channels.", ephemeral=True)

    @discord.ui.button(label="Slowmode", style=discord.ButtonStyle.secondary, emoji="🐢", custom_id="disman:slowmode")
    async def slowmode(self, interaction, button):
        await interaction.response.send_modal(SlowmodeModal())

    @discord.ui.button(label="Purge", style=discord.ButtonStyle.danger, emoji="🧹", custom_id="disman:purge")
    async def purge(self, interaction, button):
        await interaction.response.send_modal(PurgeModal())

    @discord.ui.button(label="Warn Member", style=discord.ButtonStyle.secondary, emoji="⚠️", custom_id="disman:warn")
    async def warn(self, interaction, button):
        await interaction.response.send_modal(WarnModal(self.bot))

    @discord.ui.button(label="Timeout Member", style=discord.ButtonStyle.danger, emoji="⏳", custom_id="disman:timeout")
    async def timeout_member(self, interaction, button):
        await interaction.response.send_modal(TimeoutModal())

    @discord.ui.button(label="AutoMod Status", style=discord.ButtonStyle.primary, emoji="🛡️", custom_id="disman:automod_status")
    async def automod_status(self, interaction, button):
        cfg = self.bot.config["automod"]
        rows = await self.bot.db.recent_incidents(interaction.guild.id, 10)
        await interaction.response.send_message(
            f"**AutoMod:** {'ON' if cfg['enabled'] else 'OFF'}\n"
            f"Delete threshold: **{cfg['threshold_delete']}**\n"
            f"Timeout threshold: **{cfg['threshold_timeout']}**\n"
            f"Timeout length: **{cfg['timeout_minutes']}m**\n"
            f"Recent incidents shown in database: **{len(rows)}**",
            ephemeral=True
        )

    @discord.ui.button(label="Recent Incidents", style=discord.ButtonStyle.secondary, emoji="📋", custom_id="disman:incidents")
    async def incidents(self, interaction, button):
        rows = await self.bot.db.recent_incidents(interaction.guild.id, 10)
        if not rows:
            await interaction.response.send_message("No incidents recorded.", ephemeral=True)
            return
        lines = [
            f"`{r['created_at']}` <@{r['user_id']}> — **{r['action']}** — {r['reason'][:90]}"
            for r in rows
        ]
        await interaction.response.send_message("\n".join(lines)[:1900], ephemeral=True)

    @discord.ui.button(label="Server Stats", style=discord.ButtonStyle.secondary, emoji="📊", custom_id="disman:stats")
    async def stats(self, interaction, button):
        g = interaction.guild
        bots = sum(m.bot for m in g.members)
        await interaction.response.send_message(
            f"**{g.name}**\n"
            f"Members: **{g.member_count}**\nBots: **{bots}**\n"
            f"Text channels: **{len(g.text_channels)}**\nVoice channels: **{len(g.voice_channels)}**\n"
            f"Roles: **{len(g.roles)}**\nBoosts: **{g.premium_subscription_count or 0}**",
            ephemeral=True
        )
