
import discord

class CreateChannelModal(discord.ui.Modal, title="Create Channel"):
    channel_name = discord.ui.TextInput(label="Channel name", placeholder="general")
    channel_type = discord.ui.TextInput(label="Type", placeholder="text or voice", default="text")
    category_name = discord.ui.TextInput(label="Category (optional)", required=False)

    def __init__(self, bot):
        super().__init__()
        self.bot = bot

    async def on_submit(self, interaction: discord.Interaction):
        guild = interaction.guild
        category = None
        if self.category_name.value:
            category = discord.utils.get(guild.categories, name=str(self.category_name.value))
            if not category:
                category = await guild.create_category(str(self.category_name.value), reason="DISMAN GUI")
        name = str(self.channel_name.value).strip()
        if str(self.channel_type.value).lower().startswith("v"):
            ch = await guild.create_voice_channel(name, category=category, reason="DISMAN GUI")
        else:
            ch = await guild.create_text_channel(name, category=category, reason="DISMAN GUI")
        await interaction.response.send_message(f"✅ Created {ch.mention if hasattr(ch,'mention') else ch.name}.", ephemeral=True)

class CreateRoleModal(discord.ui.Modal, title="Create Role"):
    role_name = discord.ui.TextInput(label="Role name", placeholder="Producer")
    hoist = discord.ui.TextInput(label="Display separately? yes/no", default="no")
    mentionable = discord.ui.TextInput(label="Mentionable? yes/no", default="no")

    async def on_submit(self, interaction: discord.Interaction):
        role = await interaction.guild.create_role(
            name=str(self.role_name.value),
            hoist=str(self.hoist.value).lower().startswith("y"),
            mentionable=str(self.mentionable.value).lower().startswith("y"),
            reason="DISMAN GUI"
        )
        await interaction.response.send_message(f"✅ Created role **{role.name}**.", ephemeral=True)

class SlowmodeModal(discord.ui.Modal, title="Set Slowmode"):
    seconds = discord.ui.TextInput(label="Seconds (0-21600)", default="10")

    async def on_submit(self, interaction: discord.Interaction):
        try:
            val = max(0,min(21600,int(str(self.seconds.value))))
        except ValueError:
            await interaction.response.send_message("Enter a number.", ephemeral=True)
            return
        if not isinstance(interaction.channel, discord.TextChannel):
            await interaction.response.send_message("Use this from a text channel.", ephemeral=True)
            return
        await interaction.channel.edit(slowmode_delay=val, reason=f"DISMAN by {interaction.user}")
        await interaction.response.send_message(f"✅ Slowmode set to **{val}s**.", ephemeral=True)

class PurgeModal(discord.ui.Modal, title="Purge Messages"):
    amount = discord.ui.TextInput(label="Amount", placeholder="25", default="25")

    async def on_submit(self, interaction: discord.Interaction):
        try:
            n = max(1,min(500,int(str(self.amount.value))))
        except ValueError:
            await interaction.response.send_message("Enter a number from 1 to 500.", ephemeral=True)
            return
        await interaction.response.defer(ephemeral=True)
        deleted = await interaction.channel.purge(limit=n, reason=f"DISMAN purge by {interaction.user}")
        await interaction.followup.send(f"✅ Purged **{len(deleted)}** messages.", ephemeral=True)

class WarnModal(discord.ui.Modal, title="Warn Member"):
    user_id = discord.ui.TextInput(label="User ID")
    reason = discord.ui.TextInput(label="Reason", style=discord.TextStyle.paragraph, max_length=500)

    def __init__(self, bot):
        super().__init__()
        self.bot = bot

    async def on_submit(self, interaction: discord.Interaction):
        try:
            uid = int(str(self.user_id.value))
        except ValueError:
            await interaction.response.send_message("Invalid user ID.", ephemeral=True)
            return
        member = interaction.guild.get_member(uid)
        if not member:
            await interaction.response.send_message("Member not found.", ephemeral=True)
            return
        await self.bot.db.add_warn(interaction.guild.id, uid, interaction.user.id, str(self.reason.value))
        count = await self.bot.db.warn_count(interaction.guild.id, uid)
        try:
            await member.send(f"You were warned in **{interaction.guild.name}**.\nReason: {self.reason.value}\nTotal warnings: {count}")
        except Exception:
            pass
        await interaction.response.send_message(f"⚠️ Warned {member.mention}. Total warnings: **{count}**.", ephemeral=True)

class TimeoutModal(discord.ui.Modal, title="Timeout Member"):
    user_id = discord.ui.TextInput(label="User ID")
    minutes = discord.ui.TextInput(label="Minutes", default="60")
    reason = discord.ui.TextInput(label="Reason", required=False, max_length=300)

    async def on_submit(self, interaction: discord.Interaction):
        from datetime import timedelta
        try:
            uid = int(str(self.user_id.value))
            mins = max(1,min(40320,int(str(self.minutes.value))))
        except ValueError:
            await interaction.response.send_message("Invalid user ID or minutes.", ephemeral=True)
            return
        member = interaction.guild.get_member(uid)
        if not member:
            await interaction.response.send_message("Member not found.", ephemeral=True)
            return
        try:
            await member.timeout(discord.utils.utcnow()+timedelta(minutes=mins), reason=str(self.reason.value) or f"DISMAN by {interaction.user}")
            await interaction.response.send_message(f"⏳ Timed out {member.mention} for **{mins} minutes**.", ephemeral=True)
        except discord.Forbidden:
            await interaction.response.send_message("I cannot timeout that member. Check role hierarchy.", ephemeral=True)
