
# DISMAN v1.0.0
## Discord Server Builder + Manager + AutoMod

DISMAN is a GUI-first Discord administration bot. The permanent staff dashboard is posted automatically in a configured private admin channel, so day-to-day management does not depend on slash commands or text commands.

### Main systems

- Persistent GUI control panel
- Server template builder
- Music Production / Community / Gaming / Minimal templates
- GUI channel creator
- GUI role creator
- Server structure snapshots
- Additive structure restore
- Lockdown / unlock
- Slowmode manager
- Message purge tool
- Warning system
- Member timeout tool
- AutoMod incident viewer
- Server stats
- Scam phrase detection
- Anti-spam
- Duplicate spam protection
- Mass mention protection
- Invite filtering
- Optional external-link filtering
- Bad-word filtering
- Excessive-caps filtering
- New-account risk signal
- Join-rate raid detection
- Optional automatic lockdown during join raids
- Welcome messages
- Mod logging
- SQLite database

## Why the restore is additive

DISMAN's restore feature creates missing roles, categories and channels from the latest snapshot. It does **not** automatically delete existing server content. That makes an accidental restore much safer.

## Setup

1. Install Python 3.12.
2. Create a Discord bot in the Discord Developer Portal.
3. Enable:
   - Message Content Intent
   - Server Members Intent
4. Invite DISMAN with the permissions needed for the features you want. For the full management set:
   - View Channels
   - Send Messages
   - Read Message History
   - Manage Channels
   - Manage Roles
   - Manage Messages
   - Moderate Members
   - Manage Server
   - Embed Links
5. Put the DISMAN bot role above roles it must manage/moderate.
6. Run `start.bat` once.
7. It creates `config.json`.
8. Set:
   - `token`
   - `admin_panel_channel_id`
   - `log_channel_id`
9. Start DISMAN again.

## GUI boot behavior

DISMAN automatically posts its dashboard in `admin_panel_channel_id`. It remembers the dashboard message in SQLite and edits/reuses it after restarts instead of creating a new panel every time.

## Recommended channel setup

Create a private staff channel such as:

`🧠・disman-control`

and put that channel ID in:

```json
"admin_panel_channel_id": 123456789012345678
```

Create a separate logs channel such as:

`📋・disman-logs`

and place its ID in `log_channel_id`.

## Music Production template

The Music Production builder creates a practical starting structure with:
- rules / announcements / roles / introductions
- general-production
- beats
- mixing-mastering
- plugins
- drumkits
- presets-banks
- MIDI
- loops-one-shots
- collabs
- self-promo
- feedback
- voice studio rooms
- private staff structure

It only creates items that are missing.

## AutoMod

The AutoMod engine can combine multiple signals before taking action.

Examples:
- scam phrase
- spam burst
- repeated duplicate message
- excessive mentions
- Discord invite
- blocked word
- excessive caps
- unapproved external link
- very new account

The default policy:
- score below delete threshold: no action
- score at delete threshold: delete
- score at timeout threshold: delete + timeout

Edit all thresholds in `config.json`.

## Raid defense

DISMAN tracks member joins over a rolling time window. When the join threshold is exceeded, it logs the event and can automatically lock text-channel sending for `@everyone`.

Use the GUI **Unlock** button when staff determines the raid is over.

## Important

Always test DISMAN in a private test server before giving it broad permissions in a production community.
