
import json
import logging
from pathlib import Path
import discord
from discord.ext import commands

from core.database import Database
from services.automod import AutoModEngine
from ui.dashboard import MainDashboard

BASE = Path(__file__).resolve().parent
CONFIG_PATH = BASE / "config.json"

if not CONFIG_PATH.exists():
    raise SystemExit("config.json not found. Copy config.example.json to config.json first.")

config = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(name)s | %(message)s")
log = logging.getLogger("DISMAN")

intents = discord.Intents.default()
intents.message_content = True
intents.members = True
intents.guilds = True

class DISMAN(commands.Bot):
    def __init__(self):
        super().__init__(command_prefix=commands.when_mentioned, intents=intents, help_command=None)
        self.config = config
        self.db = Database(BASE / "disman.db")
        self.automod = AutoModEngine(self)
        self._panel_ready = False

    async def setup_hook(self):
        await self.db.init()
        self.add_view(MainDashboard(self))

    async def log_event(self, guild, title, description):
        cid = int(self.config.get("log_channel_id") or 0)
        ch = guild.get_channel(cid) if cid else None
        if ch:
            embed = discord.Embed(title=title, description=description, timestamp=discord.utils.utcnow())
            try:
                await ch.send(embed=embed)
            except Exception:
                pass

    async def lockdown_guild(self, guild):
        count = 0
        everyone = guild.default_role
        for ch in guild.text_channels:
            try:
                ow = ch.overwrites_for(everyone)
                ow.send_messages = False
                await ch.set_permissions(everyone, overwrite=ow, reason="DISMAN lockdown")
                count += 1
            except Exception:
                pass
        await self.log_event(guild, "🔒 Server Lockdown", f"Sending disabled in **{count}** text channels.")
        return count

    async def unlock_guild(self, guild):
        count = 0
        everyone = guild.default_role
        for ch in guild.text_channels:
            try:
                ow = ch.overwrites_for(everyone)
                if ow.send_messages is False:
                    ow.send_messages = None
                    await ch.set_permissions(everyone, overwrite=ow, reason="DISMAN unlock")
                    count += 1
            except Exception:
                pass
        await self.log_event(guild, "🔓 Server Unlock", f"Sending restored in **{count}** text channels.")
        return count

    async def ensure_panel(self):
        cid = int(self.config.get("admin_panel_channel_id") or 0)
        if not cid:
            log.warning("admin_panel_channel_id is 0; DISMAN cannot post its GUI.")
            return
        for guild in self.guilds:
            ch = guild.get_channel(cid)
            if not ch:
                continue

            old_id = await self.db.get_kv(f"panel:{guild.id}")
            if old_id:
                try:
                    msg = await ch.fetch_message(int(old_id))
                    await msg.edit(embed=self.panel_embed(guild), view=MainDashboard(self))
                    continue
                except Exception:
                    pass

            msg = await ch.send(embed=self.panel_embed(guild), view=MainDashboard(self))
            await self.db.set_kv(f"panel:{guild.id}", msg.id)

    def panel_embed(self, guild):
        return discord.Embed(
            title="🧠 DISMAN — Discord Server Manager",
            description=(
                "**Builder • Manager • AutoMod • Raid Defense • Moderation • Backups**\n\n"
                "Everything below is GUI-driven. Staff can build server layouts, create channels/roles, "
                "snapshot and restore structure, lock/unlock the server, manage slowmode, purge, warn, "
                "timeout members, review AutoMod, and inspect server statistics.\n\n"
                "Use the template selector or buttons below."
            )
        ).set_footer(text=f"DISMAN v{self.config['version']} • {guild.name}")

bot = DISMAN()

@bot.event
async def on_ready():
    log.info("Logged in as %s (%s)", bot.user, bot.user.id)
    await bot.ensure_panel()

@bot.event
async def on_message(message: discord.Message):
    if not message.guild or message.author.bot:
        return

    # Do not moderate server managers.
    if message.author.guild_permissions.manage_messages or message.author.guild_permissions.administrator:
        return

    score, reasons = await bot.automod.scan_message(message)
    await bot.automod.enforce(message, score, reasons)

@bot.event
async def on_member_join(member: discord.Member):
    await bot.automod.member_joined(member)

    cfg = bot.config["welcome"]
    if cfg.get("enabled"):
        ch = member.guild.get_channel(int(cfg.get("channel_id") or 0))
        if ch:
            text = str(cfg.get("message","Welcome {mention}!"))
            text = text.replace("{mention}", member.mention).replace("{server}", member.guild.name)
            try:
                await ch.send(text)
            except Exception:
                pass

token = config.get("token","")
if not token or token == "PUT_BOT_TOKEN_HERE":
    raise SystemExit("Put your Discord bot token in config.json.")
bot.run(token)
