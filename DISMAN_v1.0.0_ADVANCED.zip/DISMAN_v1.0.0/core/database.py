
import aiosqlite
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS kv(
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS snapshots(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    data TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS incidents(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    channel_id INTEGER NOT NULL,
    reason TEXT NOT NULL,
    action TEXT NOT NULL,
    content TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS warns(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    moderator_id INTEGER NOT NULL,
    reason TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
"""

class Database:
    def __init__(self, path: Path):
        self.path = path

    async def init(self):
        async with aiosqlite.connect(self.path) as db:
            await db.executescript(SCHEMA)
            await db.commit()

    async def set_kv(self, key, value):
        async with aiosqlite.connect(self.path) as db:
            await db.execute(
                "INSERT INTO kv(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (key, str(value))
            )
            await db.commit()

    async def get_kv(self, key, default=None):
        async with aiosqlite.connect(self.path) as db:
            cur = await db.execute("SELECT value FROM kv WHERE key=?", (key,))
            row = await cur.fetchone()
            return row[0] if row else default

    async def add_snapshot(self, guild_id, name, data):
        async with aiosqlite.connect(self.path) as db:
            cur = await db.execute(
                "INSERT INTO snapshots(guild_id,name,data) VALUES(?,?,?)",
                (guild_id, name, data)
            )
            await db.commit()
            return cur.lastrowid

    async def latest_snapshot(self, guild_id):
        async with aiosqlite.connect(self.path) as db:
            cur = await db.execute(
                "SELECT id,name,data,created_at FROM snapshots WHERE guild_id=? ORDER BY id DESC LIMIT 1",
                (guild_id,)
            )
            return await cur.fetchone()

    async def add_incident(self, guild_id, user_id, channel_id, reason, action, content):
        async with aiosqlite.connect(self.path) as db:
            await db.execute(
                """INSERT INTO incidents(guild_id,user_id,channel_id,reason,action,content)
                VALUES(?,?,?,?,?,?)""",
                (guild_id,user_id,channel_id,reason,action,(content or "")[:3000])
            )
            await db.commit()

    async def recent_incidents(self, guild_id, limit=15):
        async with aiosqlite.connect(self.path) as db:
            db.row_factory = aiosqlite.Row
            cur = await db.execute(
                "SELECT * FROM incidents WHERE guild_id=? ORDER BY id DESC LIMIT ?",
                (guild_id, int(limit))
            )
            return await cur.fetchall()

    async def add_warn(self, guild_id, user_id, moderator_id, reason):
        async with aiosqlite.connect(self.path) as db:
            await db.execute(
                "INSERT INTO warns(guild_id,user_id,moderator_id,reason) VALUES(?,?,?,?)",
                (guild_id,user_id,moderator_id,reason)
            )
            await db.commit()

    async def warn_count(self, guild_id, user_id):
        async with aiosqlite.connect(self.path) as db:
            cur = await db.execute(
                "SELECT COUNT(*) FROM warns WHERE guild_id=? AND user_id=?",
                (guild_id,user_id)
            )
            row = await cur.fetchone()
            return int(row[0] if row else 0)
